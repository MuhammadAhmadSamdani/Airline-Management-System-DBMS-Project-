

-- Set Recovery Model ----------------------------------------------------------
ALTER DATABASE AirlineManagementSystem
SET RECOVERY FULL;


--  Perform Full Backup ---------------------------------------------------------
BACKUP DATABASE AirlineManagementSystem
TO DISK = 'C:\Backups\AirlineManagementSystem_Full.bak'
WITH FORMAT, INIT, NAME = 'Full Backup of AirlineManagementSystem';


-- Perform Differential Backup --------------------------------------------------
BACKUP DATABASE AirlineManagementSystem
TO DISK = 'C:\Backups\AirlineManagementSystem_Diff.bak'
WITH DIFFERENTIAL, INIT, NAME = 'Differential Backup of AirlineManagementSystem';


-- Perform Transaction Log Backup -----------------------------------------------
BACKUP LOG AirlineManagementSystem
TO DISK = 'C:\Backups\AirlineManagementSystem_Log.trn'
WITH INIT, NAME = 'Transaction Log Backup';


-- Restore Sequence Example (Disaster Recovery) ----------------------------------

-- Step 1: Restore full backup
RESTORE DATABASE AirlineManagementSystem
FROM DISK = 'C:\Backups\AirlineManagementSystem_Full.bak'
WITH NORECOVERY;

-- Step 2: Restore the most recent differential backup
RESTORE DATABASE AirlineManagementSystem
FROM DISK = 'C:\Backups\AirlineManagementSystem_Diff.bak'
WITH NORECOVERY;

-- Step 3: Restore all transaction logs (in sequence)
RESTORE LOG AirlineManagementSystem
FROM DISK = 'C:\Backups\AirlineManagementSystem_Log.trn'
WITH RECOVERY;


