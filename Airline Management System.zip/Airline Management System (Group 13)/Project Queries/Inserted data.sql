USE AirlineManagementSystem;

----------------------------------------------------------- DATA INSERTION -----------------------------------------------------------------

-- AirLines
INSERT INTO AirLines (AirLine_Name, AirLine_Code, Headquarters, Email, Contact_No, Founded_Year) VALUES
('Emirates', 'EK', 'Dubai, UAE', 'info', '97142955555', 1985),
('Qatar Airways', 'QR', 'Doha, Qatar', 'info', '97440226000', 1993),
('Turkish Airlines', 'TK', 'Istanbul, Turkey', 'info', '902124636363', 1933),
('Lufthansa', 'LH', 'Cologne, Germany', 'info', '496986799799', 1955),
('British Airways', 'BA', 'London, UK', 'info', '443444930787', 1974),
('Singapore Airlines', 'SQ', 'Singapore, Singapore', 'info', '6562238888', 1947),
('Cathay Pacific', 'CX', 'Hong Kong, Hong Kong', 'info', '85227473333', 1946),
('Air France', 'AF', 'Paris, France', 'info', '33172960000', 1933),
('Delta Air Lines', 'DL', 'Atlanta, USA', 'info', '18002211212', 1929),
('United Airlines', 'UA', 'Chicago, USA', 'info', '18008648331', 1926);

-- Aircraft
INSERT INTO AirCraft (Airline_id, Model, Manufacturer, Total_Seats, First_Class_Seats, Business_Class_Seats, Economy_Class_Seats, Registration_No) VALUES
(1, 'Boeing 777-300ER', 'Boeing', 364, 8, 42, 314, 10001),
(1, 'Airbus A380-800', 'Airbus', 489, 14, 76, 399, 10002),
(2, 'Boeing 787-9', 'Boeing', 283, 0, 30, 253, 10003),
(3, 'Airbus A330-300', 'Airbus', 289, 0, 28, 261, 10004),
(4, 'Airbus A320-200', 'Airbus', 168, 0, 0, 168, 10005),
(5, 'Boeing 747-400', 'Boeing', 345, 14, 52, 279, 10006),
(6, 'Airbus A350-900', 'Airbus', 300, 4, 38, 258, 10007),
(7, 'Boeing 777-300ER', 'Boeing', 340, 6, 53, 281, 10008),
(8, 'Boeing 787-10', 'Boeing', 330, 0, 46, 284, 10009),
(9, 'Airbus A220-100', 'Airbus', 100, 0, 12, 88, 10010),
(10, 'Boeing 737-900ER', 'Boeing', 179, 0, 20, 159, 10011);

-- Airports
INSERT INTO Airports (Airport_Name, Airport_Code, Airport_City, Country, TimeZone) VALUES
('Dubai International Airport', 'DXB', 'Dubai', 'UAE', 'Asia/Dubai'),
('Hamad International Airport', 'DOH', 'Doha', 'Qatar', 'Asia/Qatar'),
('Istanbul Airport', 'IST', 'Istanbul', 'Turkey', 'Europe/Istanbul'),
('Frankfurt Airport', 'FRA', 'Frankfurt', 'Germany', 'Europe/Berlin'),
('Heathrow Airport', 'LHR', 'London', 'UK', 'Europe/London'),
('Singapore Changi Airport', 'SIN', 'Singapore', 'Singapore', 'Asia/Singapore'),
('Hong Kong International Airport', 'HKG', 'Hong Kong', 'Hong Kong', 'Asia/Hong_Kong'),
('Charles de Gaulle Airport', 'CDG', 'Paris', 'France', 'Europe/Paris'),
('Los Angeles International Airport', 'LAX', 'Los Angeles', 'USA', 'America/Los_Angeles'),
('Sydney Airport', 'SYD', 'Sydney', 'Australia', 'Australia/Sydney'),
('Tokyo Narita International Airport', 'NRT', 'Tokyo', 'Japan', 'Asia/Tokyo'),
('New York JFK International Airport', 'JFK', 'New York', 'USA', 'America/New_York');

-- Runways
INSERT INTO Runways (Airport_id, Length, Width, Surface_Type) VALUES
(1, 4500, 60, 'Asphalt'),
(1, 4000, 60, 'Asphalt'),
(2, 4850, 60, 'Asphalt'),
(3, 3750, 45, 'Asphalt'),
(4, 4000, 60, 'Concrete'),
(5, 3902, 50, 'Asphalt'),
(6, 4000, 60, 'Asphalt'),
(7, 3800, 60, 'Asphalt'),
(8, 4200, 60, 'Concrete'),
(9, 3685, 45, 'Asphalt'),
(10, 3962, 60, 'Asphalt'),
(11, 4000, 60, 'Asphalt'),
(11, 2500, 45, 'Concrete'),
(12, 4423, 60, 'Asphalt'),
(12, 3623, 45, 'Asphalt');

-- Flights
INSERT INTO Flights (Airline_id, Aircraft_id, Departure_Time, Arrival_Time, Flights_Status, Ticket_Price) VALUES
(1, 1, '2025-07-01 10:00:00', '2025-07-01 14:00:00', 'On-Time', 850.00),
(2, 3, '2025-07-02 12:30:00', '2025-07-02 18:00:00', 'Boarding', 720.50),
(3, 4, '2025-07-03 08:00:00', '2025-07-03 11:30:00', 'Delayed', 490.00),
(4, 5, '2025-07-04 15:00:00', '2025-07-04 17:00:00', 'Cancelled', 300.00),
(5, 2, '2025-07-05 09:00:00', '2025-07-05 13:00:00', 'On-Time', 980.00),
(6, 6, '2025-07-06 20:00:00', '2025-07-07 06:00:00', 'On-Time', 1200.00),
(7, 7, '2025-07-08 07:00:00', '2025-07-08 14:00:00', 'Boarding', 1100.00),
(8, 8, '2025-07-09 11:00:00', '2025-07-09 13:30:00', 'On-Time', 650.00),
(9, 9, '2025-07-10 06:00:00', '2025-07-10 08:00:00', 'On-Time', 250.00),
(10, 10, '2025-07-11 14:00:00', '2025-07-11 18:00:00', 'Delayed', 580.00),
(1, 1, '2025-07-12 19:00:00', '2025-07-13 00:00:00', 'On-Time', 900.00),
(2, 3, '2025-07-13 09:00:00', '2025-07-13 14:30:00', 'On-Time', 780.00);


-- Flights_Schedules
INSERT INTO Flights_Schedules (Flight_id, Gate_No) VALUES
(1, 15), (2, 22), (3, 9), (4, 12), (5, 18),
(6, 30), (7, 45), (8, 5), (9, 10), (10, 25),
(11, 14), (12, 23);

-- Crew_Members
INSERT INTO Crew_Members (Airline_id, First_Name, Last_Name, Date_of_Birth, Gender, Nationality, Email, Contact_No, Experience_Years, Role, Salary, License_Number) VALUES
(1, 'John', 'Doe', '1980-05-15', 'Male', 'American', 'john.doe', '1234567890', 15, 'Captain', 15000.00, 'PILOT12345'),
(1, 'Jane', 'Smith', '1988-11-20', 'Female', 'British', 'jane.smith', '0987654321', 10, 'First Officer', 10000.00, 'PILOT67890'),
(2, 'Ahmed', 'Khan', '1992-03-25', 'Male', 'Qatari', 'ahmed.khan', '9741234567', 8, 'Flight Attendant', 4000.00, NULL),
(3, 'Ayse', 'Yilmaz', '1985-07-10', 'Female', 'Turkish', 'ayse.yilmaz', '90532123456', 12, 'Captain', 14000.00, 'PILOT54321'),
(4, 'Max', 'Muller', '1990-01-30', 'Male', 'German', 'max.muller', '49170123456', 7, 'Flight Attendant', 4200.00, NULL),
(5, 'Olivia', 'Evans', '1993-09-03', 'Female', 'British', 'olivia.evans', '44771234567', 6, 'Flight Attendant', 3900.00, NULL),
(6, 'Li', 'Wei', '1982-04-18', 'Male', 'Singaporean', 'li.wei', '6591234567', 18, 'Captain', 16000.00, 'PILOT98765'),
(7, 'Isabella', 'Wong', '1991-07-28', 'Female', 'Hong Konger', 'isabella.wong', '85298765432', 9, 'First Officer', 9500.00, 'PILOT11223'),
(8, 'Pierre', 'Dupont', '1987-02-14', 'Male', 'French', 'pierre.dupont', '33601234567', 11, 'Flight Attendant', 4100.00, NULL),
(9, 'Maria', 'Garcia', '1989-10-01', 'Female', 'American', 'maria.garcia', '15551239876', 7, 'Flight Attendant', 4000.00, NULL),
(10, 'David', 'Lee', '1984-06-21', 'Male', 'American', 'david.lee', '15559876543', 13, 'Captain', 14500.00, 'PILOT22334');


-- Flight_Crew
INSERT INTO Flight_Crew (Flight_id, Crew_Member_id) VALUES
(1, 1), (1, 2), (2, 3), (3, 4), (4, 5),
(5, 6), (6, 7), (7, 8), (8, 9), (9, 10),
(10, 1), (10, 2), (11, 3), (12, 4);

-- Passengers
INSERT INTO Passengers (First_Name, Last_Name, Date_of_Birth, Gender, Passport_No, Nationality, Email, Contact_No) VALUES
('Alice', 'Brown', '1995-02-01', 'Female', 'AB1234567', 'Canadian', 'alice.brown', '14161234567'),
('Bob', 'Johnson', '1980-08-10', 'Male', 'BJ9876543', 'Australian', 'bob.johnson', '61412345678'),
('Charlie', 'Davis', '1975-12-05', 'Male', 'CD1122334', 'American', 'charlie.davis', '12129876543'),
('Diana', 'Miller', '1990-04-22', 'Female', 'DM5566778', 'British', 'diana.miller', '447912345678'),
('Eve', 'White', '1983-06-18', 'Female', 'EW9900112', 'French', 'eve.white', '336123456789'),
('Frank', 'Green', '1970-11-29', 'Male', 'FG3344556', 'German', 'frank.green', '491512345678'),
('Grace', 'Hall', '2000-01-10', 'Female', 'GH7788990', 'Singaporean', 'grace.hall', '6581234567'),
('Henry', 'King', '1965-03-03', 'Male', 'HK0011223', 'Japanese', 'henry.king', '819012345678'),
('Ivy', 'Lopez', '1998-05-25', 'Female', 'IL4455667', 'Spanish', 'ivy.lopez', '34621234567'),
('Jack', 'Perez', '1986-07-07', 'Male', 'JP8899001', 'Mexican', 'jack.perez', '525512345678');

-- Seats
INSERT INTO Seats (Aircraft_id, Seat_No, Class_Type, Seat_Status) VALUES
(1, '1A', 'First Class', 'Available'), (1, '1B', 'First Class', 'Reserved'), (1, '1C', 'First Class', 'Available'),
(1, '12A', 'Business Class', 'Available'), (1, '12B', 'Business Class', 'Reserved'), (1, '20C', 'Economy Class', 'Available'),
(1, '20D', 'Economy Class', 'Reserved'), (1, '20E', 'Economy Class', 'Available'), (1, '35F', 'Economy Class', 'Available'),
(2, '2A', 'First Class', 'Available'), (2, '2B', 'First Class', 'Reserved'), (2, '10E', 'Business Class', 'Available'),
(2, '10F', 'Business Class', 'Reserved'), (2, '40G', 'Economy Class', 'Available'), (2, '40H', 'Economy Class', 'Available'),
(3, '5D', 'Business Class', 'Available'), (3, '5E', 'Business Class', 'Reserved'), (3, '15A', 'Economy Class', 'Available'),
(3, '15B', 'Economy Class', 'Available'), (4, '15F', 'Economy Class', 'Reserved'), (4, '16A', 'Economy Class', 'Available'),
(5, '3C', 'First Class', 'Available'), (5, '8D', 'Business Class', 'Available'), (5, '25E', 'Economy Class', 'Available'),
(6, '4A', 'First Class', 'Reserved'), (6, '7B', 'Business Class', 'Available'), (6, '22C', 'Economy Class', 'Available'),
(7, '1D', 'First Class', 'Available'), (7, '15E', 'Business Class', 'Available'), (7, '30F', 'Economy Class', 'Available'),
(8, '6A', 'Business Class', 'Available'), (8, '28B', 'Economy Class', 'Available'), (9, '3A', 'Business Class', 'Available'),
(9, '8B', 'Economy Class', 'Available'), (10, '10C', 'Business Class', 'Available'), (10, '20D', 'Economy Class', 'Available');

-- Tickets
INSERT INTO Tickets (Flight_id, Passenger_id, Seat_id, Ticket_Status, Ticket_Price, Booking) VALUES
(1, 1, 2, 'Sold', 850.00, '2025-06-01'),
(2, 2, 4, 'Sold', 720.50, '2025-06-05'),
(3, 3, 5, 'Sold', 490.00, '2025-06-07'),
(5, 4, 1, 'Sold', 980.00, '2025-06-02'),
(1, 5, 3, 'Available', 850.00, '2025-06-09'),
(6, 6, 26, 'Sold', 1200.00, '2025-06-10'),
(7, 7, 29, 'Sold', 1100.00, '2025-06-11'),
(8, 8, 31, 'Sold', 650.00, '2025-06-12'),
(9, 9, 33, 'Sold', 250.00, '2025-06-13'),
(10, 10, 35, 'Sold', 580.00, '2025-06-14'),
(1, 2, 6, 'Sold', 850.00, '2025-06-15'),
(2, 1, 16, 'Sold', 720.50, '2025-06-16');

-- Maintenances
INSERT INTO Maintenances (Aircraft_id, Maintenance_Type, Maintenance, Status) VALUES
(1, 'A-Check', '2025-05-20', 'Completed'),
(3, 'C-Check', '2025-06-10', 'Pending'),
(2, 'Engine Overhaul', '2025-04-15', 'Completed'),
(4, 'B-Check', '2025-06-20', 'Pending'),
(5, 'Landing Gear Inspection', '2025-05-01', 'Completed'),
(6, 'A-Check', '2025-06-05', 'Completed'),
(7, 'C-Check', '2025-07-01', 'Pending'),
(8, 'Engine Repair', '2025-05-10', 'Completed'),
(9, 'Scheduled Check', '2025-06-15', 'Pending'),
(10, 'Heavy Maintenance', '2025-03-20', 'Completed');

-- SecurityCheck
INSERT INTO SecurityCheck (Airport_id, Check_Type, Status) VALUES
(1, 'Baggage', 'Completed'), (2, 'Passenger', 'Completed'), (3, 'Aircraft', 'Pending'),
(4, 'Baggage', 'Completed'), (5, 'Passenger', 'Completed'), (6, 'Aircraft', 'Completed'),
(7, 'Baggage', 'Completed'), (8, 'Passenger', 'Completed'), (9, 'Aircraft', 'Pending'),
(10, 'Baggage', 'Completed'), (11, 'Passenger', 'Completed'), (12, 'Aircraft', 'Completed');

-- Baggage
INSERT INTO Baggage (Passenger_id, Weight, Baggage_Type, Status) VALUES
(1, 20, 'Checked', 'Loaded'), (2, 7, 'Hand', 'Loaded'), (3, 25, 'Checked', 'Delayed'),
(4, 5, 'Hand', 'Loaded'), (5, 18, 'Checked', 'Loaded'), (6, 22, 'Checked', 'Loaded'),
(7, 8, 'Hand', 'Loaded'), (8, 30, 'Checked', 'Lost'), (9, 10, 'Hand', 'Loaded'),
(10, 15, 'Checked', 'Loaded');

-- Cargo
INSERT INTO Cargo (Flight_id, Description, Weight, Sender_Details, Receiver_Details) VALUES
(1, 'Medical Supplies', 500, 'MediCorp Inc.', 'Global Health Systems'),
(2, 'Electronics', 1200, 'Tech Solutions', 'E-Commerce Retail'),
(3, 'Automotive Parts', 800, 'Auto Manufacturers', 'Car Repair Shop'),
(5, 'Textiles', 300, 'Fashion House', 'Boutique Store'),
(1, 'Perishable Goods', 150, 'Fresh Foods Co.', 'Restaurant Supply'),
(6, 'High Value Art', 750, 'Art Gallery', 'Museum of Modern Art'),
(7, 'Machinery Components', 1500, 'Industrial Solutions', 'Factory Plant'),
(8, 'Printed Materials', 200, 'Publishing House', 'Bookstore Chain'),
(9, 'Pharmaceuticals', 600, 'Pharma Global', 'Hospital Pharmacy'),
(10, 'Live Animals', 100, 'Pet Transport', 'Animal Sanctuary');

-- Flight_Delays
INSERT INTO Flight_Delays (Flight_id, Reason, New_Departure_Time) VALUES
(3, 'Technical', '2025-07-03 09:30:00'),
(1, 'Weather', '2025-07-01 11:00:00'),
(10, 'Crew Issue', '2025-07-11 15:30:00');

-- Flight_Cancellations
INSERT INTO Flight_Cancellations (Flight_id, Reason, Refund_Status) VALUES
(4, 'Crew Issue', 'Refunded');

-- Passenger_Feedback
INSERT INTO Passenger_Feedback (Passenger_id, Flight_id, Rating, Comments) VALUES
(1, 1, 5, 'Excellent flight, very comfortable.'),
(2, 2, 4, 'Good service, but departure was a bit late.'),
(3, 3, 2, 'Flight delayed significantly, very inconvenient.'),
(4, 5, 5, 'Fantastic experience, highly recommend!'),
(5, 1, 4, 'Smooth journey, but food could be better.'),
(6, 6, 5, 'Very luxurious and timely.'),
(7, 7, 3, 'In-flight entertainment was not working well.'),
(8, 8, 5, 'Professional crew and smooth landing.'),
(9, 9, 4, 'Short flight, but efficient.'),
(10, 10, 2, 'Long delay with poor communication.');

-- Fuel_Consumption
INSERT INTO Fuel_Consumption (Aircraft_id, Fuel_Used, Fuel_Remaining, Refuel_Status, Fuel_Cost) VALUES
(1, 60000, 10000, 'Done', '75000 USD'),
(3, 45000, 5000, 'Done', '55000 USD'),
(4, 20000, 2000, 'Pending', '25000 USD'),
(2, 70000, 15000, 'Done', '85000 USD'),
(5, 55000, 8000, 'Done', '68000 USD'),
(6, 65000, 12000, 'Done', '80000 USD'),
(7, 50000, 7000, 'Pending', '62000 USD'),
(8, 40000, 4000, 'Done', '48000 USD'),
(9, 15000, 1000, 'Done', '18000 USD'),
(10, 30000, 3000, 'Pending', '36000 USD');

-- Boarding_Passes
INSERT INTO Boarding_Passes (Ticket_id, Passenger_id, Flight_id, Boarding_Time, Status) VALUES
(1, 1, 1, '2025-07-01 09:30:00', 'Check In'),
(2, 2, 2, '2025-07-02 12:00:00', 'Check In'),
(3, 3, 3, '2025-07-03 07:30:00', 'Check'),
(4, 4, 5, '2025-07-05 08:30:00', 'Check In'),
(5, 5, 1, '2025-07-01 09:30:00', 'Check In'),
(6, 6, 6, '2025-07-06 19:30:00', 'Check In'),
(7, 7, 7, '2025-07-08 06:30:00', 'Check In'),
(8, 8, 8, '2025-07-09 10:30:00', 'Check In'),
(9, 9, 9, '2025-07-10 05:30:00', 'Check In'),
(10, 10, 10, '2025-07-11 13:30:00', 'Check'),
(11, 2, 1, '2025-07-01 09:30:00', 'Check In'),
(12, 1, 2, '2025-07-02 12:00:00', 'Check In');

-- VIP_Services
INSERT INTO VIP_Services (Passenger_id, Flight_id, Service_Type, Status) VALUES
(1, 1, 'Lounge Access', 'Confirmed'),
(4, 5, 'Priority Boarding', 'Confirmed'),
(3, 3, 'Chauffeur', 'Cancelled'),
(6, 6, 'Lounge Access', 'Confirmed'),
(8, 8, 'Chauffeur', 'Confirmed');

-- Flight_Attendance_Record
INSERT INTO Flight_Attendance_Record (Crew_Member_id, Flight_id, Status) VALUES
(1, 1, 'Present'), (2, 1, 'Present'), (3, 2, 'Present'), (4, 3, 'Present'), (5, 4, 'Absent'),
(6, 5, 'Present'), (7, 6, 'Present'), (8, 7, 'Present'), (9, 8, 'Present'), (10, 9, 'Present'),
(1, 10, 'Present'), (2, 10, 'Present'), (3, 11, 'Present'), (4, 12, 'Present');

-- InFlight_Entertainment
INSERT INTO InFlight_Entertainment (Flight_id, Entertainment_Type, Availability_Status) VALUES
(1, 'Movie', 'Available'), (1, 'Wifi', 'Available'), (2, 'Music', 'Available'),
(3, 'Movie', 'Unavailable'), (5, 'Wifi', 'Available'), (6, 'Movie', 'Available'),
(7, 'Music', 'Available'), (8, 'Wifi', 'Available'), (9, 'Movie', 'Available'),
(10, 'Music', 'Available'), (11, 'Movie', 'Available'), (12, 'Wifi', 'Available');

-- Crew_Shift
INSERT INTO Crew_Shift (Crew_Member_id, Shift_Start_Time, Shift_End_Time, Duty_Status) VALUES
(1, '2025-07-01 06:00:00', '2025-07-01 16:00:00', 'Completed'),
(2, '2025-07-01 06:00:00', '2025-07-01 16:00:00', 'Completed'),
(3, '2025-07-02 09:00:00', '2025-07-02 19:00:00', 'Completed'),
(4, '2025-07-03 05:00:00', '2025-07-03 13:00:00', 'Ongoing'),
(5, '2025-07-04 12:00:00', '2025-07-04 18:00:00', 'Completed'),
(6, '2025-07-05 07:00:00', '2025-07-05 17:00:00', 'Completed'),
(7, '2025-07-06 18:00:00', '2025-07-07 08:00:00', 'Completed'),
(8, '2025-07-07 04:00:00', '2025-07-07 14:00:00', 'Completed'),
(9, '2025-07-08 10:00:00', '2025-07-08 20:00:00', 'Completed'),
(10, '2025-07-09 05:00:00', '2025-07-09 10:00:00', 'Completed'),
(1, '2025-07-10 13:00:00', '2025-07-10 23:00:00', 'Ongoing');

-- Hotel_Partnership
INSERT INTO Hotel_Partnership (Hotel_Name, Location, Hotel_E, Hotel_P, Partnership_Status, Discount_Per) VALUES
('The Grand Hyatt', 'Dubai', 'grandhyattdubai', '97143171234', 'Active', '15%'),
('Sheraton Doha', 'Doha', 'sheratondoha', '97444854444', 'Active', '10%'),
('Hilton Istanbul Bosphorus', 'Istanbul', 'hiltonistanbul', '902123156000', 'Active', '20%'),
('Marriott Frankfurt', 'Frankfurt', 'marriottfrankfurt', '496917283940', 'Inactive', '0%'),
('The Savoy London', 'London', 'thesavoylondon', '442078364343', 'Active', '12%'),
('Marina Bay Sands', 'Singapore', 'marinabaysands', '6566888888', 'Active', '18%'),
('The Peninsula Hong Kong', 'Hong Kong', 'thepeninsulahkg', '85229202888', 'Active', '15%'),
('Shangri-La Paris', 'Paris', 'shangrilaparis', '33153671998', 'Active', '10%'),
('The Beverly Hilton', 'Los Angeles', 'beverlyhilton', '13102747777', 'Inactive', '0%'),
('Four Seasons Sydney', 'Sydney', 'fourseasonssydney', '61292503100', 'Active', '14%');

-- Catering_Services
INSERT INTO Catering_Services (Airline_id, Catering_Provider, Provider_P, Rating) VALUES
(1, 'Alpha Catering', '971501112233', 5),
(2, 'Sky Bites', '97433445566', 4),
(3, 'Taste of Turkey', '905551234567', 4),
(4, 'German Delights', '491719876543', 3),
(5, 'Britannia Meals', '447890123456', 5),
(6, 'Asia Cuisine', '65912345678', 5),
(7, 'Orient Flavors', '85267890123', 4),
(8, 'French Gourmand', '33678901234', 4),
(9, 'American Fare', '15551122334', 3),
(10, 'Global Kitchen', '15559988776', 5);