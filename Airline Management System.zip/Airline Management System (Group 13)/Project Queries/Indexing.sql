
--------------------------------------------------------------- AirLines

-- Drop existing clustered index if any
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AirLines_Clustered')
    DROP INDEX IX_AirLines_Clustered ON AirLines;

SET STATISTICS IO ON;
SELECT * FROM AirLines WHERE AirLine_ID = 1;
SET STATISTICS IO OFF;



-- Drop if already exists
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AirLines_NonClustered')
    DROP INDEX IX_AirLines_NonClustered ON AirLines;

-- Create non-clustered index on Country
CREATE NONCLUSTERED INDEX IX_AirLines_NonClustered
ON AirLines(AirLine_Name);


SET STATISTICS IO ON;
SELECT * FROM AirLines WHERE AirLine_Name = 'Emirates';
SET STATISTICS IO OFF;




--------------------------------------------------------------- AirCraft

-- Drop existing clustered index if any
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AirCraft_Clustered')
    DROP INDEX IX_AirCraft_Clustered ON AirCraft;

SET STATISTICS IO ON;
SELECT * FROM AirCraft WHERE AirCraft_id = 1;
SET STATISTICS IO OFF;



--------------------------------------------------------------- Airports

-- Drop existing clustered index if any
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Airport_Clustered')
    DROP INDEX IX_Airport_Clustered ON Airports;

SET STATISTICS IO ON;
SELECT * FROM Airports WHERE Airport_ID = 1;
SET STATISTICS IO OFF;


-- Drop if already exists
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Airport_NonClustered')
    DROP INDEX IX_Airports_NonClustered ON Airports;

-- Create non-clustered index on Country
CREATE NONCLUSTERED INDEX IX_Airports_NonClustered
ON Airports(Airport_Name);

SET STATISTICS IO ON;
SELECT * FROM Airports WHERE Airport_Name = 'Dubai International Airport';
SET STATISTICS IO OFF;

--------------------------------------------------------------- Flights

-- Drop existing clustered index if any
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Flights_Clustered')
    DROP INDEX IX_Flights_Clustered ON Flights;

SET STATISTICS IO ON;
SELECT * FROM Flights WHERE Flight_ID = 1;
SET STATISTICS IO OFF;



--------------------------------------------------------------- Crew_Members

-- Drop existing clustered index if any
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Crew_Members_Clustered')
    DROP INDEX IX_Crew_Members_Clustered ON Crew_Members;

SET STATISTICS IO ON;
SELECT * FROM Crew_Members WHERE Crew_Member_ID = 1;
SET STATISTICS IO OFF;


-- Drop if already exists
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Crew_Members_NonClustered')
    DROP INDEX IX_Crew_Members_NonClustered ON Airports;

-- Create non-clustered index on Country
CREATE NONCLUSTERED INDEX IX_Crew_Members_NonClustered
ON Crew_Members(Full_Name);

SET STATISTICS IO ON;
SELECT * FROM Crew_Members WHERE Full_Name = 'Jane Smith';
SET STATISTICS IO OFF;




--------------------------------------------------------------- Passengers

-- Drop existing clustered index if any
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Passengers_Clustered')
    DROP INDEX IX_Passengers_Clustered ON Passengers;

SET STATISTICS IO ON;
SELECT * FROM Passengers WHERE Passengers_ID = 1;
SET STATISTICS IO OFF;


-- Drop if already exists
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Passengers_NonClustered')
    DROP INDEX IX_Passengers_NonClustered ON Passengers;

-- Create non-clustered index on Country
CREATE NONCLUSTERED INDEX IX_Passengers_NonClustered
ON Passengers(Full_Name);

SET STATISTICS IO ON;
SELECT * FROM Passengers WHERE Full_Name = 'Eve White';
SET STATISTICS IO OFF;

--------------------------------------------------------------- Tickets
-- Drop existing clustered index if any
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Tickets_Clustered')
    DROP INDEX IX_Tickets_Clustered ON Tickets;

SET STATISTICS IO ON;
SELECT * FROM Tickets WHERE Ticket_ID = 1;
SET STATISTICS IO OFF;



--------------------------------------------------------------- Boarding Pass

-- Drop existing clustered index if any
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Boarding_Passes_Clustered')
    DROP INDEX IX_Boarding_Passes_Clustered ON Boarding_Passes;

SET STATISTICS IO ON;
SELECT * FROM Boarding_Passes WHERE Boarding_ID = 1;
SET STATISTICS IO OFF;


-----------------------------------------------------------------------------------







