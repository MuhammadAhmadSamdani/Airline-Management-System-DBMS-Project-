
USE AirlineManagementSystem

CREATE PROCEDURE ViewDataForAirLines
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare variables including fuel consumption fields
    DECLARE @AirLine_Name VARCHAR(100),
            @AirLine_Code VARCHAR(100),
            @AirLine_headquarters VARCHAR(100),
            @Email VARCHAR(100),
            @Phone VARCHAR(100),
            @Founded_year INT,
            @Model VARCHAR(100),
            @Manufacturer VARCHAR(100),
            @Total_Seats INT,
            @First_Class_Seats INT,
            @Business_Class_Seats INT,
            @Economy_Class_Seats INT,
            @Registration_No VARCHAR(100),
            @Airport_name VARCHAR(100),
            @Airport_code VARCHAR(100),
            @City VARCHAR(100),
            @Country VARCHAR(100),
            @TimeZone VARCHAR(100),
            @Runway_length VARCHAR(100),
            @Runway_width VARCHAR(100),
            @Runway_surface VARCHAR(100),
            @Maintenance_Type VARCHAR(100),
            @Maintenance_Date VARCHAR(20),
            @Maintenance_Status VARCHAR(20),
            @Security_Check VARCHAR(20),
            @Status_Check VARCHAR(20),
            @Fuel_Used INT,
            @Fuel_Remaining INT,
            @Fuel_Cost VARCHAR(100),
            @ReFuel_Status VARCHAR(20);

    -- Check if any data matches the search key (now including Fuel_Consumption)
    IF EXISTS (
        SELECT 1
        FROM Airlines Air
        JOIN AirCraft Craft ON Air.Airline_ID = Craft.Airline_id
        JOIN Airports Port ON Craft.Aircraft_ID = Port.Airport_ID
        JOIN Runways Run ON Run.Airport_id = Port.Airport_ID
        JOIN Maintenances M ON M.Aircraft_id = Craft.Aircraft_ID
        JOIN SecurityCheck S ON S.Airport_id = Port.Airport_ID
        LEFT JOIN Fuel_Consumption F ON F.Aircraft_id = Craft.Aircraft_ID
        WHERE
            Air.Airline_Name = @SearchKey OR
            Air.Airline_Code = @SearchKey OR
            Air.Headquarters = @SearchKey OR
            Port.Airport_Code = @SearchKey OR
            CAST(Craft.Registration_No AS VARCHAR(100)) = @SearchKey
    )
    BEGIN
        -- Select and assign values to variables (including fuel data)
        SELECT TOP 1
            @AirLine_Name = Air.AirLine_Name,
            @AirLine_Code = Air.AirLine_Code,
            @AirLine_headquarters = Air.Headquarters,
            @Founded_year = Air.Founded_Year,
            @Model = Craft.Model,
            @Manufacturer = Craft.Manufacturer,
            @Total_Seats = Craft.Total_Seats,
            @First_Class_Seats = Craft.First_Class_Seats,
            @Business_Class_Seats = Craft.Business_Class_Seats,
            @Economy_Class_Seats = Craft.Economy_Class_Seats,
            @Registration_No = CAST(Craft.Registration_No AS VARCHAR(100)),
            @Airport_name = Port.Airport_Name,
            @Airport_code = Port.Airport_Code,
            @City = Port.Airport_City,
            @Country = Port.Country,
            @TimeZone = Port.TimeZone,
            @Runway_length = Run.Runway_Length,
            @Runway_width = Run.Runway_Width,
            @Runway_surface = Run.Surface_Type,
            @Maintenance_Type = M.Maintenance_Type,
            @Maintenance_Date = M.Maintenance_Date,
            @Maintenance_Status = M.Status,
            @Security_Check = S.Check_Type,
            @Status_Check = S.Status,
            @Fuel_Used = F.Fuel_Used,
            @Fuel_Remaining = F.Fuel_Remaining,
            @Fuel_Cost = F.Fuel_Cost,
            @ReFuel_Status = F.Refuel_Status
        FROM Airlines Air
        JOIN AirCraft Craft ON Air.Airline_ID = Craft.Airline_id
        JOIN Airports Port ON Craft.Aircraft_ID = Port.Airport_ID
        JOIN Runways Run ON Run.Airport_id = Port.Airport_ID
        JOIN Maintenances M ON M.Aircraft_id = Craft.Aircraft_ID
        JOIN SecurityCheck S ON S.Airport_id = Port.Airport_ID
        LEFT JOIN Fuel_Consumption F ON F.Aircraft_id = Craft.Aircraft_ID
        WHERE
            Air.Airline_Name = @SearchKey OR
            Air.Airline_Code = @SearchKey OR
            Air.Headquarters = @SearchKey OR
            Port.Airport_Code = @SearchKey OR
            CAST(Craft.Registration_No AS VARCHAR(100)) = @SearchKey
        ORDER BY Air.Airline_Name;

        -- Print the collected information (with fuel data)
        PRINT '------------------- AIRLINES MANAGEMENT SYSTEM ------------------';
        PRINT ' ';
        PRINT 'Airline Name: ' + ISNULL(@AirLine_Name, 'N/A');
        PRINT 'Airline Code: ' + ISNULL(@AirLine_Code, 'N/A');
        PRINT 'Headquarters: ' + ISNULL(@AirLine_headquarters, 'N/A');
        PRINT 'Founded Year: ' + ISNULL(CAST(@Founded_year AS VARCHAR(4)), 'N/A');
        PRINT ' ';
        PRINT '------------------------------------------------------------------';
        PRINT ' ';
        PRINT '---------------------- INFO ABOUT AIRCRAFT  ----------------------';
        PRINT ' ';
        PRINT 'Model: ' + ISNULL(@Model, 'N/A');
        PRINT 'Manufacturer: ' + ISNULL(@Manufacturer, 'N/A');
        PRINT 'Total Seats: ' + ISNULL(CAST(@Total_Seats AS VARCHAR(10)), 'N/A');
        PRINT 'First Class Seats: ' + ISNULL(CAST(@First_Class_Seats AS VARCHAR(10)), 'N/A');
        PRINT 'Business Class Seats: ' + ISNULL(CAST(@Business_Class_Seats AS VARCHAR(10)), 'N/A');
        PRINT 'Economy Class Seats: ' + ISNULL(CAST(@Economy_Class_Seats AS VARCHAR(10)), 'N/A');
        PRINT 'Registration No: ' + ISNULL(@Registration_No, 'N/A');
        PRINT 'Maintenance Type: ' + ISNULL(@Maintenance_Type, 'N/A');
        PRINT 'Maintenance Date: ' + ISNULL(@Maintenance_Date, 'N/A');
        PRINT 'Maintenance Status: ' + ISNULL(@Maintenance_Status, 'N/A');
        PRINT 'Fuel Used: ' + ISNULL(CAST(@Fuel_Used AS VARCHAR(10)), 'N/A');
        PRINT 'Fuel Remaining: ' + ISNULL(CAST(@Fuel_Remaining AS VARCHAR(10)), 'N/A');
        PRINT 'Fuel Cost: ' + ISNULL(@Fuel_Cost, 'N/A');
        PRINT 'Refuel Status: ' + ISNULL(@ReFuel_Status, 'N/A');
        PRINT ' ';
        PRINT '------------------------------------------------------------------';
        PRINT ' ';
        PRINT '---------------------- INFO ABOUT AIRPORT  ------------------------';
        PRINT ' ';
        PRINT 'Airport Name: ' + ISNULL(@Airport_name, 'N/A');
        PRINT 'Airport Code: ' + ISNULL(@Airport_code, 'N/A');
        PRINT 'City: ' + ISNULL(@City, 'N/A');
        PRINT 'Country: ' + ISNULL(@Country, 'N/A');
        PRINT 'Time Zone: ' + ISNULL(@TimeZone, 'N/A');
        PRINT 'Runway Length: ' + ISNULL(@Runway_length, 'N/A');
        PRINT 'Runway Width: ' + ISNULL(@Runway_width, 'N/A');
        PRINT 'Runway Surface: ' + ISNULL(@Runway_surface, 'N/A');
        PRINT 'Security Check Type: ' + ISNULL(@Security_Check, 'N/A');
        PRINT 'Status Check: ' + ISNULL(@Status_Check, 'N/A');
        PRINT ' ';
        PRINT '------------------------------------------------------------------';
    END
    ELSE
    BEGIN
        PRINT 'No data found for the given search key.';
    END
END;

EXEC ViewDataForAirLines @SearchKey = 'BA';




CREATE PROCEDURE ViewDataForFlights
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    -- Flight Information
    DECLARE @FlightID INT,
            @AirlineName VARCHAR(100),
            @AirlineCode VARCHAR(10),
            @AircraftModel VARCHAR(100),
            @RegistrationNo VARCHAR(20),
            @DepartureTime VARCHAR(50),
            @ArrivalTime VARCHAR(50),
            @Duration VARCHAR(20),
            @FlightStatus VARCHAR(50),
            @TicketPrice DECIMAL(10,2),
            @GateNo INT,
            @ScheduleGateNo INT,
            @EntertainmentType VARCHAR(25),
            @EntertainmentStatus VARCHAR(25),
            @DelayReason VARCHAR(50),
            @NewDepartureTime VARCHAR(50),
            @CancellationReason VARCHAR(50),
            @RefundStatus VARCHAR(20);

    -- Check if any flight data matches the search key
    IF EXISTS (
        SELECT 1 FROM Flights F
        JOIN Airlines A ON F.Airline_id = A.Airline_ID
        JOIN AirCraft AC ON F.Aircraft_id = AC.Aircraft_ID
        LEFT JOIN Flights_Schedules FS ON FS.Flight_id = F.Flight_ID
        LEFT JOIN InFlight_Entertainment IE ON IE.Flight_id = F.Flight_ID
        LEFT JOIN Flight_Delays FD ON FD.Flight_id = F.Flight_ID
        LEFT JOIN Flight_Cancellations FC ON FC.Flight_id = F.Flight_ID
        WHERE 
            F.Flight_ID = TRY_CAST(@SearchKey AS INT) OR
            A.Airline_Code = @SearchKey OR
            AC.Registration_No = TRY_CAST(@SearchKey AS INT) OR
            F.Flights_Status = @SearchKey
    )
    BEGIN
        -- Get flight information
        SELECT TOP 1
            @FlightID = F.Flight_ID,
            @AirlineName = A.Airline_Name,
            @AirlineCode = A.Airline_Code,
            @AircraftModel = AC.Model,
            @RegistrationNo = CAST(AC.Registration_No AS VARCHAR(20)),
            @DepartureTime = CONVERT(VARCHAR(20), F.Departure_Time, 120),
            @ArrivalTime = CONVERT(VARCHAR(20), F.Arrival_Time, 120),
            @Duration = F.Duration,
            @FlightStatus = F.Flights_Status,
            @TicketPrice = F.Ticket_Price,
            @ScheduleGateNo = FS.Gate_No,
            @EntertainmentType = IE.Entertainment_Type,
            @EntertainmentStatus = IE.Availability_Status,
            @DelayReason = FD.Reason,
            @NewDepartureTime = CONVERT(VARCHAR(20), FD.New_Departure_Time, 120),
            @CancellationReason = FC.Reason,
            @RefundStatus = FC.Refund_Status
        FROM Flights F
        JOIN Airlines A ON F.Airline_id = A.Airline_ID
        JOIN AirCraft AC ON F.Aircraft_id = AC.Aircraft_ID
        LEFT JOIN Flights_Schedules FS ON FS.Flight_id = F.Flight_ID
        LEFT JOIN InFlight_Entertainment IE ON IE.Flight_id = F.Flight_ID
        LEFT JOIN Flight_Delays FD ON FD.Flight_id = F.Flight_ID
        LEFT JOIN Flight_Cancellations FC ON FC.Flight_id = F.Flight_ID
        WHERE 
            F.Flight_ID = TRY_CAST(@SearchKey AS INT) OR
            A.Airline_Code = @SearchKey OR
            AC.Registration_No = TRY_CAST(@SearchKey AS INT) OR
            F.Flights_Status = @SearchKey
        ORDER BY F.Departure_Time DESC;

        -- Print flight information in the same style as ViewDataForAirLines
        PRINT '------------------- FLIGHT MANAGEMENT SYSTEM --------------------';
        PRINT ' ';
        PRINT 'Flight ID: ' + ISNULL(CAST(@FlightID AS VARCHAR(10)), 'N/A');
        PRINT 'Airline: ' + ISNULL(@AirlineName, 'N/A') + ' (' + ISNULL(@AirlineCode, 'N/A') + ')';
        PRINT 'Aircraft: ' + ISNULL(@AircraftModel, 'N/A') + ' [Reg: ' + ISNULL(@RegistrationNo, 'N/A') + ']';
        PRINT ' ';
        PRINT '------------------------------------------------------------------';
        PRINT ' ';
        PRINT '---------------------- FLIGHT DETAILS ---------------------------';
        PRINT ' ';
        PRINT 'Departure Time: ' + ISNULL(@DepartureTime, 'N/A');
        PRINT 'Arrival Time: ' + ISNULL(@ArrivalTime, 'N/A');
        PRINT 'Duration: ' + ISNULL(@Duration, 'N/A');
        PRINT 'Status: ' + ISNULL(@FlightStatus, 'N/A');
        PRINT 'Ticket Price: $' + ISNULL(CAST(@TicketPrice AS VARCHAR(20)), 'N/A');
        PRINT 'Gate Number: ' + ISNULL(CAST(@GateNo AS VARCHAR(10)), 'N/A');
        PRINT 'Scheduled Gate: ' + ISNULL(CAST(@ScheduleGateNo AS VARCHAR(10)), 'N/A');
        PRINT 'Entertainment: ' + ISNULL(@EntertainmentType, 'N/A') + 
              ' (' + ISNULL(@EntertainmentStatus, 'N/A') + ')';
        PRINT ' ';
        PRINT '------------------------------------------------------------------';
        PRINT ' ';
        PRINT '---------------------- FLIGHT STATUS ----------------------------';
        PRINT ' ';
        PRINT 'Delay Reason: ' + ISNULL(@DelayReason, 'N/A');
        PRINT 'New Departure: ' + ISNULL(@NewDepartureTime, 'N/A');
        PRINT 'Cancellation Reason: ' + ISNULL(@CancellationReason, 'N/A');
        PRINT 'Refund Status: ' + ISNULL(@RefundStatus, 'N/A');
        PRINT ' ';
        PRINT '------------------------------------------------------------------';
    END
    ELSE
    BEGIN
        PRINT 'No flight data found for the given search key.';
    END
END;

EXEC ViewDataForFlights @SearchKey = '1';



CREATE PROCEDURE ViewDataForCrew
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare variables for crew data
    DECLARE @Crew_Member_ID INT,
            @Airline_Name VARCHAR(100),
            @First_Name VARCHAR(100),
            @Last_Name VARCHAR(100),
            @Full_Name VARCHAR(200),
            @Date_of_Birth DATE,
            @Gender VARCHAR(20),
            @Nationality VARCHAR(100),
            @Email VARCHAR(100),
            @Contact_No VARCHAR(100),
            @Experience_Years INT,
            @Role VARCHAR(100),
            @Salary DECIMAL(10, 2),
            @License_Number VARCHAR(100),
            @Shift_ID INT,
            @Shift_Start_Time VARCHAR(50),
            @Shift_End_Time VARCHAR(50),
            @Duty_Duration INT,
            @Duty_Status VARCHAR(25),
            @Flight_ID INT,
            @Flight_Status VARCHAR(50),
            @Departure_Time VARCHAR(50),
            @Arrival_Time VARCHAR(50),
            @Attendance_Status VARCHAR(20);

    -- Check if any crew data matches the search key
    IF EXISTS (
        SELECT 1
        FROM Crew_Members CM
        JOIN Airlines A ON CM.Airline_id = A.Airline_ID
        LEFT JOIN Crew_Shift CS ON CS.Crew_Member_id = CM.Crew_Member_ID
        LEFT JOIN Flight_Crew FC ON FC.Crew_Member_id = CM.Crew_Member_ID
        LEFT JOIN Flights F ON F.Flight_ID = FC.Flight_id
        LEFT JOIN Flight_Attendance_Record FAR ON FAR.Crew_Member_id = CM.Crew_Member_ID AND FAR.Flight_id = F.Flight_ID
        WHERE
            CM.Crew_Member_ID = TRY_CAST(@SearchKey AS INT) OR
            CM.First_Name LIKE '%' + @SearchKey + '%' OR
            CM.Last_Name LIKE '%' + @SearchKey + '%' OR
            CM.License_Number = @SearchKey OR
            A.Airline_Code = @SearchKey
    )
    BEGIN
        -- Select and assign values to variables
        SELECT TOP 1
            @Crew_Member_ID = CM.Crew_Member_ID,
            @Airline_Name = A.Airline_Name,
            @First_Name = CM.First_Name,
            @Last_Name = CM.Last_Name,
            @Full_Name = CM.First_Name + ' ' + CM.Last_Name,
            @Date_of_Birth = CM.Date_of_Birth,
            @Gender = CM.Gender,
            @Nationality = CM.Nationality,
            @Email = CM.Contact_Email,
            @Contact_No = CM.Contact_Phone,
            @Experience_Years = CM.Experience_Years,
            @Role = CM.Role,
            @Salary = CM.Salary,
            @License_Number = CM.License_Number,
            @Shift_ID = CS.Shift_ID,
            @Shift_Start_Time = CONVERT(VARCHAR(20), CS.Shift_Start_Time, 120),
            @Shift_End_Time = CONVERT(VARCHAR(20), CS.Shift_End_Time, 120),
            @Duty_Duration = CS.Duty_Duration,
            @Duty_Status = CS.Duty_Status,
            @Flight_ID = F.Flight_ID,
            @Flight_Status = F.Flights_Status,
            @Departure_Time = CONVERT(VARCHAR(20), F.Departure_Time, 120),
            @Arrival_Time = CONVERT(VARCHAR(20), F.Arrival_Time, 120),
            @Attendance_Status = FAR.Status
        FROM Crew_Members CM
        JOIN Airlines A ON CM.Airline_id = A.Airline_ID
        LEFT JOIN Crew_Shift CS ON CS.Crew_Member_id = CM.Crew_Member_ID
        LEFT JOIN Flight_Crew FC ON FC.Crew_Member_id = CM.Crew_Member_ID
        LEFT JOIN Flights F ON F.Flight_ID = FC.Flight_id
        LEFT JOIN Flight_Attendance_Record FAR ON FAR.Crew_Member_id = CM.Crew_Member_ID AND FAR.Flight_id = F.Flight_ID
        WHERE
            CM.Crew_Member_ID = TRY_CAST(@SearchKey AS INT) OR
            CM.First_Name LIKE '%' + @SearchKey + '%' OR
            CM.Last_Name LIKE '%' + @SearchKey + '%' OR
            CM.License_Number = @SearchKey OR
            A.Airline_Code = @SearchKey
        ORDER BY CM.Crew_Member_ID;

        -- Print the collected information
        PRINT '------------------- CREW MANAGEMENT SYSTEM ------------------';
        PRINT ' ';
        PRINT 'Crew Member ID: ' + ISNULL(CAST(@Crew_Member_ID AS VARCHAR(10)), 'N/A');
        PRINT 'Airline Name: ' + ISNULL(@Airline_Name, 'N/A');
        PRINT 'Full Name: ' + ISNULL(@Full_Name, 'N/A');
        PRINT 'Date of Birth: ' + ISNULL(CONVERT(VARCHAR(10), @Date_of_Birth, 120), 'N/A');
        PRINT 'Gender: ' + ISNULL(@Gender, 'N/A');
        PRINT 'Nationality: ' + ISNULL(@Nationality, 'N/A');
        PRINT 'Email: ' + ISNULL(@Email, 'N/A');
        PRINT 'Contact No: ' + ISNULL(@Contact_No, 'N/A');
        PRINT 'Experience Years: ' + ISNULL(CAST(@Experience_Years AS VARCHAR(10)), 'N/A');
        PRINT 'Role: ' + ISNULL(@Role, 'N/A');
        PRINT 'Salary: ' + ISNULL(CAST(@Salary AS VARCHAR(20)), 'N/A');
        PRINT 'License Number: ' + ISNULL(@License_Number, 'N/A');
        PRINT ' ';
        PRINT '------------------------------------------------------------------';
        PRINT ' ';
        PRINT '---------------------- SHIFT INFORMATION ----------------------';
        PRINT ' ';
        PRINT 'Shift ID: ' + ISNULL(CAST(@Shift_ID AS VARCHAR(10)), 'N/A');
        PRINT 'Shift Start Time: ' + ISNULL(@Shift_Start_Time, 'N/A');
        PRINT 'Shift End Time: ' + ISNULL(@Shift_End_Time, 'N/A');
        PRINT 'Duty Duration (minutes): ' + ISNULL(CAST(@Duty_Duration AS VARCHAR(10)), 'N/A');
        PRINT 'Duty Status: ' + ISNULL(@Duty_Status, 'N/A');
        PRINT ' ';
        PRINT '------------------------------------------------------------------';
        PRINT ' ';
        PRINT '---------------------- FLIGHT ASSIGNMENT ------------------------';
        PRINT ' ';
        PRINT 'Flight ID: ' + ISNULL(CAST(@Flight_ID AS VARCHAR(10)), 'N/A');
        PRINT 'Flight Status: ' + ISNULL(@Flight_Status, 'N/A');
        PRINT 'Departure Time: ' + ISNULL(@Departure_Time, 'N/A');
        PRINT 'Arrival Time: ' + ISNULL(@Arrival_Time, 'N/A');
        PRINT 'Attendance Status: ' + ISNULL(@Attendance_Status, 'N/A');
        PRINT ' ';
        PRINT '------------------------------------------------------------------';
    END
    ELSE
    BEGIN
        PRINT 'No crew data found for the given search key.';
    END
END;


EXEC ViewDataForCrew @SearchKey = '2';





CREATE PROCEDURE ViewPassengerData
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare variables for passenger data
    DECLARE @Passenger_ID INT,
            @First_Name VARCHAR(100),
            @Last_Name VARCHAR(100),
            @Full_Name VARCHAR(200),
            @Date_of_Birth DATE,
            @Gender VARCHAR(20),
            @Passport_No VARCHAR(100),
            @Nationality VARCHAR(100),
            @Email VARCHAR(100),
            @Contact_No VARCHAR(100),
            @Contact_Phone VARCHAR(100),
            @Ticket_ID INT,
            @Ticket_Status VARCHAR(20),
            @Ticket_Price DECIMAL(10, 2),
            @Booking_Date VARCHAR(10),
            @Seat_No VARCHAR(10),
            @Seat_Status VARCHAR(10),
            @Class_Type VARCHAR(20),
            @Boarding_Time DATETIME,
            @Boarding_Status VARCHAR(20),
            @VIP_Service_Type VARCHAR(100),
            @VIP_Service_Status VARCHAR(20),
            @Baggage_Type VARCHAR(20),
            @Baggage_Weight INT,
            @Baggage_Status VARCHAR(20);

    -- Check if any passenger data matches the search key
    IF EXISTS (
        SELECT 1
        FROM Passengers P
        LEFT JOIN Tickets T ON P.Passengers_ID = T.Passenger_id
        LEFT JOIN Seats S ON T.Seat_id = S.Seat_id
        LEFT JOIN Boarding_Passes BP ON BP.Passenger_id = P.Passengers_ID
        LEFT JOIN VIP_Services VS ON VS.Passenger_id = P.Passengers_ID
        LEFT JOIN Baggage B ON B.Passenger_id = P.Passengers_ID
        WHERE
            P.Passengers_ID = TRY_CAST(@SearchKey AS INT) OR
            P.First_Name LIKE '%' + @SearchKey + '%' OR
            P.Last_Name LIKE '%' + @SearchKey + '%' OR
            P.Passport_No = @SearchKey OR
            P.Contact_No = @SearchKey
    )
    BEGIN
        -- Select and assign values to variables
        SELECT TOP 1
            @Passenger_ID = P.Passengers_ID,
            @First_Name = P.First_Name,
            @Last_Name = P.Last_Name,
            @Full_Name = P.First_Name + ' ' + P.Last_Name,
            @Date_of_Birth = P.Date_of_Birth,
            @Gender = P.Gender,
            @Passport_No = P.Passport_No,
            @Nationality = P.Nationality,
            @Email = P.Contact_Email,
            @Contact_No = P.Contact_No,
            @Contact_Phone = P.Contact_Phone,
            @Ticket_ID = T.Ticket_ID,
            @Ticket_Status = T.Ticket_Status,
            @Ticket_Price = T.Ticket_Price,
            @Booking_Date = T.Booking_Date,
            @Seat_No = S.Seat_No,
            @Seat_Status = S.Seat_Status,
            @Class_Type = S.Class_Type,
            @Boarding_Time = BP.Boarding_Time,
            @Boarding_Status = BP.Status,
            @VIP_Service_Type = VS.Service_Type,
            @VIP_Service_Status = VS.Status,
            @Baggage_Type = B.Baggage_Type,
            @Baggage_Weight = B.Weight,
            @Baggage_Status = B.Status
        FROM Passengers P
        LEFT JOIN Tickets T ON P.Passengers_ID = T.Passenger_id
        LEFT JOIN Seats S ON T.Seat_id = S.Seat_id
        LEFT JOIN Boarding_Passes BP ON BP.Passenger_id = P.Passengers_ID
        LEFT JOIN VIP_Services VS ON VS.Passenger_id = P.Passengers_ID
        LEFT JOIN Baggage B ON B.Passenger_id = P.Passengers_ID
        WHERE
            P.Passengers_ID = TRY_CAST(@SearchKey AS INT) OR
            P.First_Name LIKE '%' + @SearchKey + '%' OR
            P.Last_Name LIKE '%' + @SearchKey + '%' OR
            P.Passport_No = @SearchKey OR
            P.Contact_No = @SearchKey
        ORDER BY P.Passengers_ID;

        -- Print the collected information
        PRINT '------------------- PASSENGER MANAGEMENT SYSTEM ------------------';
        PRINT ' ';
        PRINT 'Passenger ID: ' + ISNULL(CAST(@Passenger_ID AS VARCHAR(10)), 'N/A');
        PRINT 'Full Name: ' + ISNULL(@Full_Name, 'N/A');
        PRINT 'Date of Birth: ' + ISNULL(CONVERT(VARCHAR(10), @Date_of_Birth, 120), 'N/A');
        PRINT 'Gender: ' + ISNULL(@Gender, 'N/A');
        PRINT 'Nationality: ' + ISNULL(@Nationality, 'N/A');
        PRINT 'Email: ' + ISNULL(@Email, 'N/A');
        PRINT 'Contact No: ' + ISNULL(@Contact_No, 'N/A');
        PRINT 'Contact Phone: ' + ISNULL(@Contact_Phone, 'N/A');
        PRINT ' ';
        PRINT '---------------------- TICKET INFORMATION ----------------------';
        PRINT ' ';
        PRINT 'Ticket ID: ' + ISNULL(CAST(@Ticket_ID AS VARCHAR(10)), 'N/A');
        PRINT 'Ticket Status: ' + ISNULL(@Ticket_Status, 'N/A');
        PRINT 'Ticket Price: ' + ISNULL(CAST(@Ticket_Price AS VARCHAR(20)), 'N/A');
        PRINT 'Booking Date: ' + ISNULL(@Booking_Date, 'N/A');
        PRINT ' ';
        PRINT '---------------------- SEAT INFORMATION ----------------------';
        PRINT ' ';
        PRINT 'Seat No: ' + ISNULL(@Seat_No, 'N/A');
        PRINT 'Seat Status: ' + ISNULL(@Seat_Status, 'N/A');
        PRINT 'Class Type: ' + ISNULL(@Class_Type, 'N/A');
        PRINT ' ';
        PRINT '---------------------- BOARDING INFORMATION ----------------------';
        PRINT ' ';
        PRINT 'Boarding Time: ' + ISNULL(CONVERT(VARCHAR(20), @Boarding_Time, 120), 'N/A');
        PRINT 'Boarding Status: ' + ISNULL(@Boarding_Status, 'N/A');
        PRINT ' ';
        PRINT '---------------------- VIP SERVICE ----------------------';
        PRINT ' ';
        PRINT 'VIP Service Type: ' + ISNULL(@VIP_Service_Type, 'N/A');
        PRINT 'VIP Service Status: ' + ISNULL(@VIP_Service_Status, 'N/A');
        PRINT ' ';
        PRINT '---------------------- BAGGAGE INFORMATION ----------------------';
        PRINT ' ';
        PRINT 'Baggage Type: ' + ISNULL(@Baggage_Type, 'N/A');
        PRINT 'Baggage Weight: ' + ISNULL(CAST(@Baggage_Weight AS VARCHAR(10)), 'N/A');
        PRINT 'Baggage Status: ' + ISNULL(@Baggage_Status, 'N/A');
        PRINT '------------------------------------------------------------------';
    END
    ELSE
    BEGIN
        PRINT 'No passenger data found for the given search key.';
    END
END;



EXEC ViewPassengerData @SearchKey = '1';










CREATE PROCEDURE ViewCargoData
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare variables for cargo data
    DECLARE @Cargo_ID INT,
            @Flight_ID INT,
            @Description VARCHAR(100),
            @Weight INT,
            @Sender_Details VARCHAR(100),
            @Receiver_Details VARCHAR(100);

    -- Check if any cargo data matches the search key
    IF EXISTS (
        SELECT 1
        FROM Cargo C
        LEFT JOIN Flights F ON C.Flight_id = F.Flight_ID
        WHERE
            C.Cargo_ID = TRY_CAST(@SearchKey AS INT) OR
            C.Flight_id = TRY_CAST(@SearchKey AS INT) OR
            C.Description LIKE '%' + @SearchKey + '%' OR
            C.Sender_Details LIKE '%' + @SearchKey + '%' OR
            C.Receiver_Details LIKE '%' + @SearchKey + '%'
    )
    BEGIN
        -- Select and assign values to variables
        SELECT TOP 1
            @Cargo_ID = C.Cargo_ID,
            @Flight_ID = C.Flight_id,
            @Description = C.Description,
            @Weight = C.Weight,
            @Sender_Details = C.Sender_Details,
            @Receiver_Details = C.Receiver_Details
        FROM Cargo C
        LEFT JOIN Flights F ON C.Flight_id = F.Flight_ID
        WHERE
            C.Cargo_ID = TRY_CAST(@SearchKey AS INT) OR
            C.Flight_id = TRY_CAST(@SearchKey AS INT) OR
            C.Description LIKE '%' + @SearchKey + '%' OR
            C.Sender_Details LIKE '%' + @SearchKey + '%' OR
            C.Receiver_Details LIKE '%' + @SearchKey + '%'
        ORDER BY C.Cargo_ID;

        -- Print the collected information
        PRINT '------------------- CARGO MANAGEMENT SYSTEM ------------------';
        PRINT ' ';
        PRINT 'Cargo ID: ' + ISNULL(CAST(@Cargo_ID AS VARCHAR(10)), 'N/A');
        PRINT 'Flight ID: ' + ISNULL(CAST(@Flight_ID AS VARCHAR(10)), 'N/A');
        PRINT 'Description: ' + ISNULL(@Description, 'N/A');
        PRINT 'Weight: ' + ISNULL(CAST(@Weight AS VARCHAR(10)), 'N/A');
        PRINT 'Sender Details: ' + ISNULL(@Sender_Details, 'N/A');
        PRINT 'Receiver Details: ' + ISNULL(@Receiver_Details, 'N/A');
        PRINT '------------------------------------------------------------------';
    END
    ELSE
    BEGIN
        PRINT 'No cargo data found for the given search key.';
    END
END;



EXEC ViewCargoData @SearchKey = '1';







CREATE PROCEDURE ViewPartnershipAndCateringData
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare variables for Hotel Partnership Data
    DECLARE @Hotel_ID INT,
            @Hotel_Name VARCHAR(100),
            @Location VARCHAR(100),
            @Hotel_E VARCHAR(100),
            @Hotel_Email VARCHAR(100),
            @Hotel_P VARCHAR(100),
            @Hotel_Phone_No VARCHAR(100),
            @Partnership_Status VARCHAR(20),
            @Discount_Per VARCHAR(50);

    -- Declare variables for Catering Services Data
    DECLARE @Catering_ID INT,
            @Airline_id INT,
            @Catering_Provider VARCHAR(100),
            @Provider_P VARCHAR(100),
            @Provider_No VARCHAR(100),
            @Rating INT;

    -- Check if any Hotel Partnership data matches the search key
    IF EXISTS (
        SELECT 1
        FROM Hotel_Partnership HP
        WHERE
            HP.Hotel_ID = TRY_CAST(@SearchKey AS INT) OR
            HP.Hotel_Name LIKE '%' + @SearchKey + '%' OR
            HP.Location LIKE '%' + @SearchKey + '%' OR
            HP.Hotel_E LIKE '%' + @SearchKey + '%'
    )
    BEGIN
        -- Select and assign values to variables from Hotel Partnership
        SELECT TOP 1
            @Hotel_ID = HP.Hotel_ID,
            @Hotel_Name = HP.Hotel_Name,
            @Location = HP.Location,
            @Hotel_E = HP.Hotel_E,
            @Hotel_Email = HP.Hotel_Email,
            @Hotel_P = HP.Hotel_P,
            @Hotel_Phone_No = HP.Hotel_Phone_No,
            @Partnership_Status = HP.Partnership_Status,
            @Discount_Per = HP.Discount_Per
        FROM Hotel_Partnership HP
        WHERE
            HP.Hotel_ID = TRY_CAST(@SearchKey AS INT) OR
            HP.Hotel_Name LIKE '%' + @SearchKey + '%' OR
            HP.Location LIKE '%' + @SearchKey + '%' OR
            HP.Hotel_E LIKE '%' + @SearchKey + '%';

        -- Print Hotel Partnership data
        PRINT '------------------- HOTEL PARTNERSHIP MANAGEMENT ------------------';
        PRINT ' ';
        PRINT 'Hotel ID: ' + ISNULL(CAST(@Hotel_ID AS VARCHAR(10)), 'N/A');
        PRINT 'Hotel Name: ' + ISNULL(@Hotel_Name, 'N/A');
        PRINT 'Location: ' + ISNULL(@Location, 'N/A');
        PRINT 'Hotel Email: ' + ISNULL(@Hotel_Email, 'N/A');
        PRINT 'Hotel Phone No: ' + ISNULL(@Hotel_Phone_No, 'N/A');
        PRINT 'Partnership Status: ' + ISNULL(@Partnership_Status, 'N/A');
        PRINT 'Discount Percentage: ' + ISNULL(@Discount_Per, 'N/A');
        PRINT '---------------------------------------------------------------------';
    END
    ELSE
    BEGIN
        PRINT 'No hotel partnership data found for the given search key.';
    END

    -- Check if any Catering Services data matches the search key
    IF EXISTS (
        SELECT 1
        FROM Catering_Services CS
        LEFT JOIN AirLines A ON CS.Airline_id = A.Airline_ID
        WHERE
            CS.Catering_ID = TRY_CAST(@SearchKey AS INT) OR
            CS.Airline_id = TRY_CAST(@SearchKey AS INT) OR
            CS.Catering_Provider LIKE '%' + @SearchKey + '%' OR
            CS.Provider_P LIKE '%' + @SearchKey + '%'
    )
    BEGIN
        -- Select and assign values to variables from Catering Services
        SELECT TOP 1
            @Catering_ID = CS.Catering_ID,
            @Airline_id = CS.Airline_id,
            @Catering_Provider = CS.Catering_Provider,
            @Provider_P = CS.Provider_P,
            @Provider_No = CS.Provider_No,
            @Rating = CS.Rating
        FROM Catering_Services CS
        LEFT JOIN AirLines A ON CS.Airline_id = A.Airline_ID
        WHERE
            CS.Catering_ID = TRY_CAST(@SearchKey AS INT) OR
            CS.Airline_id = TRY_CAST(@SearchKey AS INT) OR
            CS.Catering_Provider LIKE '%' + @SearchKey + '%' OR
            CS.Provider_P LIKE '%' + @SearchKey + '%';

        -- Print Catering Services data
        PRINT '------------------- CATERING SERVICES MANAGEMENT ------------------';
        PRINT ' ';
        PRINT 'Catering ID: ' + ISNULL(CAST(@Catering_ID AS VARCHAR(10)), 'N/A');
        PRINT 'Airline ID: ' + ISNULL(CAST(@Airline_id AS VARCHAR(10)), 'N/A');
        PRINT 'Catering Provider: ' + ISNULL(@Catering_Provider, 'N/A');
        PRINT 'Provider Phone No: ' + ISNULL(@Provider_No, 'N/A');
        PRINT 'Rating: ' + ISNULL(CAST(@Rating AS VARCHAR(10)), 'N/A');
        PRINT '---------------------------------------------------------------------';
    END
    ELSE
    BEGIN
        PRINT 'No catering services data found for the given search key.';
    END
END;


EXEC ViewPartnershipAndCateringData @SearchKey = '1';



