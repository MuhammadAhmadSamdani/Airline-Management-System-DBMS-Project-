
----------------------------------------------------------------- USE MASTER
USE master;

----------------------------------------------------------------- CHECKING NEW DATABASE CREATION
-- Check if the database exists
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'AirlineManagementSystem')
BEGIN
    -- Terminate all active connections
    ALTER DATABASE [AirlineManagementSystem] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    
    -- Drop the existing database
    DROP DATABASE [AirlineManagementSystem];
END


-- Create a new database
CREATE DATABASE [AirlineManagementSystem];

USE AirlineManagementSystem

----------------------------------------------------------- TABLES -----------------------------------------------------------------

CREATE TABLE AirLines (
	Airline_ID INT PRIMARY KEY IDENTITY (1,1),
	AirLine_Name VARCHAR(100),
	AirLine_Code VARCHAR(100),
	Headquarters VARCHAR(100),
	Email VARCHAR(100),
	Contact_No VARCHAR(20),
	Founded_Year INT,
);

CREATE TABLE AirCraft (
	Aircraft_ID INT PRIMARY KEY IDENTITY (1,1),
	Airline_id INT,
	Model VARCHAR(100),
	Manufacturer VARCHAR(100),
	Total_Seats INT,
	First_Class_Seats INT,
	Business_Class_Seats INT,
	Economy_Class_Seats INT,
	Registration_No INT,
	FOREIGN KEY (Airline_id) REFERENCES AirLines(Airline_ID)
);

CREATE TABLE Airports (
	Airport_ID INT PRIMARY KEY IDENTITY (1,1),
	Airport_Name VARCHAR(100),
	Airport_Code VARCHAR(100),
	Airport_City VARCHAR(100),
	Country VARCHAR(100),
	TimeZone VARCHAR(100)
);

CREATE TABLE Runways (
	Runway_ID INT PRIMARY KEY IDENTITY (1,1),
	Airport_id INT,
	Length INT,
	Runway_Length AS (CAST(Length AS VARCHAR(10)) + ' Meters'),
	Width INT,
	Runway_Width AS (CAST(Width AS VARCHAR(10)) + ' Meters'),
	Surface_Type VARCHAR(100),
	FOREIGN KEY (Airport_id) REFERENCES Airports(Airport_ID)
);

CREATE TABLE Flights (
	Flight_ID INT PRIMARY KEY IDENTITY(1,1),
	Airline_id INT,
	Aircraft_id INT,
	Departure_Time DATETIME,
	Arrival_Time DATETIME,
	Duration AS CONVERT(VARCHAR(8), Arrival_Time - Departure_Time, 108), -- Format as HH:MM:SS
	Flights_Status VARCHAR(50) CHECK (Flights_Status IN ('On-Time', 'Boarding', 'Delayed', 'Cancelled')),
	Ticket_Price DECIMAL(10, 2),
	FOREIGN KEY (Airline_id) REFERENCES AirLines(Airline_ID),
	FOREIGN KEY (Aircraft_id) REFERENCES AirCraft(Aircraft_ID)
);

CREATE TABLE Flights_Schedules (
	Schedule_ID INT PRIMARY KEY IDENTITY (1,1),
	Flight_id INT,
	Gate_No INT,
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID)
);

CREATE TABLE Crew_Members (
	Crew_Member_ID INT PRIMARY KEY IDENTITY(1,1),
	Airline_id INT,
	First_Name VARCHAR(100),
	Last_Name VARCHAR(100),
	Full_Name AS (First_Name + ' ' + Last_Name),  
	Date_of_Birth DATE,
	Gender VARCHAR(20),
	Nationality VARCHAR(100),
	Email VARCHAR(100),
	Contact_Email AS (CONCAT (Email , '@gmail.com') ),  
	Contact_No VARCHAR(100),
	Contact_Phone AS (CONCAT ('+' , Contact_No) ),       
	Experience_Years INT,
	Role VARCHAR(100),
	Salary DECIMAL(10, 2),  
	License_Number VARCHAR(100),
	FOREIGN KEY (Airline_id) REFERENCES AirLines(Airline_ID)
);

CREATE TABLE Flight_Crew (
	Flight_Crew_ID INT PRIMARY KEY IDENTITY(1,1),
	Flight_id INT,
	Crew_Member_id INT,
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID),
	FOREIGN KEY (Crew_Member_id) REFERENCES Crew_Members(Crew_Member_ID)
);

CREATE TABLE Passengers (
	Passengers_ID INT PRIMARY KEY IDENTITY(1,1),
	First_Name VARCHAR(100),
	Last_Name VARCHAR(100),
	Full_Name AS (CAST(First_Name AS VARCHAR(100)) + ' ' + CAST(Last_Name AS VARCHAR(100))),
	Date_of_Birth DATE,
	Gender VARCHAR(20),
	Passport_No VARCHAR(100),
	Nationality VARCHAR(100),
	Email VARCHAR(100),
	Contact_Email AS (CAST(Email AS VARCHAR(100)) + '@gmail.com'),
	Contact_No VARCHAR(100),
	Contact_Phone AS ('+' + CAST(Contact_No AS VARCHAR(100)))
);
 
CREATE TABLE Seats (
	Seat_id INT PRIMARY KEY IDENTITY(1,1),
	Aircraft_id INT,
	Seat_No VARCHAR(10),  
	Class_Type VARCHAR(20) CHECK (Class_Type IN ('First Class', 'Business Class', 'Economy Class')),
	Seat_Status VARCHAR(10) CHECK (Seat_Status IN ('Available', 'Reserved')),
	FOREIGN KEY (Aircraft_id) REFERENCES AirCraft(Aircraft_ID)
);

CREATE TABLE Tickets (
	Ticket_ID INT PRIMARY KEY IDENTITY(1,1),
	Flight_id INT,
	Passenger_id INT,
	Seat_id INT,
	Ticket_Status VARCHAR(20) CHECK (Ticket_Status IN ('Available', 'Sold')),
	Ticket_Price DECIMAL(10, 2),  
	Booking DATE,
	Booking_Date AS CONVERT(VARCHAR(10), Booking, 103), 
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID),
	FOREIGN KEY (Passenger_id) REFERENCES Passengers(Passengers_ID),
	FOREIGN KEY (Seat_id) REFERENCES Seats(Seat_ID)
);

CREATE TABLE Maintenances (
	Maintenance_ID INT PRIMARY KEY IDENTITY(1,1),
	Aircraft_id INT,
	Maintenance_Type VARCHAR(100),
	Maintenance DATE,
	Maintenance_Date AS CONVERT(VARCHAR(10), Maintenance, 103), 
	Status VARCHAR(20) CHECK (Status IN ('Pending', 'Completed')),
	FOREIGN KEY (Aircraft_id) REFERENCES AirCraft(Aircraft_ID)
);

CREATE TABLE SecurityCheck (
	Security_Check_ID INT PRIMARY KEY IDENTITY(1,1),
	Airport_id INT,
	Check_Type VARCHAR(20) CHECK (Check_Type IN ('Baggage', 'Passenger', 'Aircraft')),
	Status VARCHAR(20) CHECK (Status IN ('Pending', 'Completed')),
	FOREIGN KEY (Airport_id) REFERENCES Airports(Airport_ID)
);

CREATE TABLE Baggage (
	Baggage_ID INT PRIMARY KEY IDENTITY (1,1),
	Passenger_id INT,
	Weight INT,
	Baggage_Type VARCHAR(20) CHECK (Baggage_Type IN ('Hand', 'Checked')),
	Status VARCHAR(20) CHECK (Status IN ('Loaded', 'Delayed', 'Lost')),
	FOREIGN KEY (Passenger_id) REFERENCES Passengers(Passengers_ID)
);

CREATE TABLE Cargo (
	Cargo_ID INT PRIMARY KEY IDENTITY(1,1),
	Flight_id INT,
	Description VARCHAR(100),
	Weight INT,
	Sender_Details VARCHAR(100),
	Receiver_Details VARCHAR(100),
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID)
);

CREATE TABLE Flight_Delays (
	Delay_ID INT PRIMARY KEY IDENTITY(1,1),
	Flight_id INT,
	Reason VARCHAR(20) CHECK (Reason IN ('Weather', 'Technical', 'Crew Issue')),
	New_Departure_Time DATETIME,
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID)
);

CREATE TABLE Flight_Cancellations (
	Cancellation_ID INT PRIMARY KEY IDENTITY(1,1),
	Flight_id INT,
	Reason VARCHAR(20) CHECK (Reason IN ('Weather', 'Technical', 'Crew Issue')),
	Refund_Status VARCHAR(20) CHECK (Refund_Status IN ('Pending', 'Refunded')),
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID)
);

CREATE TABLE Passenger_Feedback (
	Feedback_ID INT PRIMARY KEY IDENTITY(1,1),
	Passenger_id INT,
	Flight_id INT,
	Rating INT CHECK (Rating BETWEEN 1 AND 5),
	Comments VARCHAR(100),
	FOREIGN KEY (Passenger_id) REFERENCES Passengers(Passengers_ID),
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID)
);

CREATE TABLE Fuel_Consumption (
	Fuel_ID INT PRIMARY KEY IDENTITY(1,1),
	Aircraft_id INT,
	Fuel_Used INT, 
	Fuel_Remaining INT,  
	Refuel_Status VARCHAR(20) CHECK (Refuel_Status IN ('Pending', 'Done')),
	Fuel_Cost VARCHAR(100),
	FOREIGN KEY (Aircraft_id) REFERENCES AirCraft(Aircraft_ID),
);

CREATE TABLE Boarding_Passes (
	Boarding_ID INT PRIMARY KEY IDENTITY(1,1),
	Ticket_id INT, 
	Passenger_id INT,
	Flight_id INT,
	Boarding_Time DATETIME,
	Status VARCHAR(20) CHECK (Status IN ('Check', 'Check In')),
	FOREIGN KEY (Ticket_id) REFERENCES Tickets(Ticket_ID),
	FOREIGN KEY (Passenger_id) REFERENCES Passengers(Passengers_ID),
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID)
);

CREATE TABLE VIP_Services (
	VIP_Service_ID INT PRIMARY KEY IDENTITY(1,1),
	Passenger_id INT,
	Flight_id INT,
	Service_Type VARCHAR(100) CHECK (Service_Type IN ('Lounge Access', 'Priority Boarding', 'Chauffeur')),
	Status VARCHAR(20) CHECK (Status IN ('Confirmed', 'Cancelled')),
	FOREIGN KEY (Passenger_id) REFERENCES Passengers(Passengers_ID),
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID)
);

CREATE TABLE Flight_Attendance_Record (
	Attendance_ID INT PRIMARY KEY IDENTITY(1,1),
	Crew_Member_id INT,
	Flight_id INT,
	Status VARCHAR(20) CHECK (Status IN ('Present', 'Absent')),
	FOREIGN KEY (Crew_Member_id) REFERENCES Crew_Members(Crew_Member_ID),
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID)
);

CREATE TABLE InFlight_Entertainment (
	Inflight_ID INT PRIMARY KEY IDENTITY(1,1),
	Flight_id INT,
	Entertainment_Type VARCHAR(25) CHECK (Entertainment_Type IN ('Movie', 'Music', 'Wifi')),
	Availability_Status VARCHAR(25) CHECK (Availability_Status IN ('Available', 'Unavailable')),
	FOREIGN KEY (Flight_id) REFERENCES Flights(Flight_ID)
);

	CREATE TABLE Crew_Shift (
		Shift_ID INT PRIMARY KEY IDENTITY(1,1),
		Crew_Member_id INT,
		Shift_Start_Time DATETIME,
		Shift_End_Time DATETIME,
		Duty_Duration AS DATEDIFF(MINUTE, Shift_Start_Time, Shift_End_Time),  
		Duty_Status VARCHAR(25) CHECK (Duty_Status IN ('Completed', 'Ongoing')),
		FOREIGN KEY (Crew_Member_id) REFERENCES Crew_Members(Crew_Member_ID)
	);

CREATE TABLE Hotel_Partnership (
	Hotel_ID INT PRIMARY KEY IDENTITY(1,1),
	Hotel_Name VARCHAR(100),
	Location VARCHAR(100),
	Hotel_E VARCHAR(100),
	Hotel_Email AS (CONCAT (Hotel_E , '@gmail.com')),
	Hotel_P VARCHAR(100),
	Hotel_Phone_No AS ('+' + Hotel_P),
	Partnership_Status VARCHAR(20) CHECK (Partnership_Status IN ('Active', 'Inactive')),
	Discount_Per VARCHAR(50)
);

CREATE TABLE Catering_Services (
	Catering_ID INT PRIMARY KEY IDENTITY(1,1),
	Airline_id INT,
	Catering_Provider VARCHAR(100),
	Provider_P VARCHAR(100),
	Provider_No AS (CONCAT ('+' , Provider_P)),
	Rating INT CHECK (Rating BETWEEN 1 AND 5),
	FOREIGN KEY (Airline_id) REFERENCES AirLines(Airline_ID)
);





