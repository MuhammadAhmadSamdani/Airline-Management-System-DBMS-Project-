
	
----------------------------------------------------------------------- AirLines Table

-- Add a new column 'Website' to store airline's website link
ALTER TABLE AirLines
ADD Website VARCHAR(100);

-- Update airline name and email for airline with ID = 1
UPDATE AirLines
SET AirLine_Name = 'Global Air Express',
    Email = 'support@globalairexpress.com'
WHERE Airline_ID = 1;

-- Delete the airline record where Airline_ID = 2
DELETE FROM AirLines
WHERE Airline_ID = 2;



----------------------------------------------------------------------- Flights Table

-- Add a new column 'Website' to store airline's website link
ALTER TABLE AirLines
ADD Website VARCHAR(100);

-- Update airline name and email for airline with ID = 1
UPDATE AirLines
SET AirLine_Name = 'Global Air Express',
    Email = 'support@globalairexpress.com'
WHERE Airline_ID = 1;

-- Delete the airline record where Airline_ID = 2
DELETE FROM AirLines
WHERE Airline_ID = 2;



----------------------------------------------------------------------- Crew_Members Table

-- Add a column to specify shift type for crew members
ALTER TABLE Crew_Members
ADD Shift_Type VARCHAR(50) CHECK (Shift_Type IN ('Morning', 'Evening', 'Night'));

-- Update the role and salary of the crew member with ID = 5
UPDATE Crew_Members
SET Role = 'Senior Pilot',
    Salary = 150000
WHERE Crew_Member_ID = 5;

-- Delete all crew members who are trainees with less than 1 year of experience
DELETE FROM Crew_Members
WHERE Experience_Years < 1
AND Role = 'Trainee';



----------------------------------------------------------------------- Passengers Table

-- Add a column to specify travel class for each passenger
ALTER TABLE Passengers
ADD Travel_Class VARCHAR(50) CHECK (Travel_Class IN ('First Class', 'Business Class', 'Economy'));

-- Update contact number and nationality for passenger with ID = 10
UPDATE Passengers
SET Contact_No = '3001234567',
    Nationality = 'Canadian'
WHERE Passengers_ID = 10;

-- Delete the passenger record with the specified passport number
DELETE FROM Passengers
WHERE Passport_No = 'A1234567';



