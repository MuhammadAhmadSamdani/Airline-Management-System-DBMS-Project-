

----------------------------------------------------- View For AirLines Related Data
CREATE VIEW view_Airlines AS
SELECT 
    Air.AirLine_Name,
    Air.Headquarters,
	Air.Founded_Year,
	Air.Email,
	Air.Contact_No,
    Craft.Manufacturer,
	Craft.Model,
	Craft.Registration_No,
	Craft.Total_Seats,
	Craft.Economy_Class_Seats,
	Craft.Business_Class_Seats,
	Craft.First_Class_Seats
FROM 
    AirLines Air
JOIN 
    AirCraft Craft ON Air.Airline_ID = Craft.Airline_id;

------------------------------------------------------------------- View Data Command
SELECT * FROM view_Airlines;
-------------------------------------------------------------------------------------




--------------------------------------------------------------- View For Flight  Data
CREATE VIEW view_Flights AS
SELECT
	Fli.Flight_ID,
	Fli.Arrival_Time,
	Fli.Departure_Time,
	Fli.Duration,
	Fli.Flights_Status,
	Fli.Ticket_Price

FROM 
	Flights Fli;


------------------------------------------------------------------- View Data Command
SELECT * FROM view_Flights;
-------------------------------------------------------------------------------------



--------------------------------------------------------------- View For Airport Data
CREATE VIEW view_Airport AS
SELECT 
	Pot.Airport_Name, Pot.Airport_Code, Pot.Airport_City, Pot.Country, Pot.TimeZone,
	Run.Surface_Type, Run.Runway_Length, Run.Runway_Width
FROM
	Airports Pot
JOIN Runways Run ON Pot.Airport_ID = Run.Airport_id;

------------------------------------------------------------------- View Data Command
SELECT * FROM view_Airport;
-------------------------------------------------------------------------------------





------------------------------------------------------------- View For Passenger Data
CREATE VIEW view_Passenger AS
SELECT 
	Pass.Full_Name, Pass.Date_of_Birth, Pass.Gender, Pass.Contact_Email, Pass.Contact_Phone,
	Tic.Booking_Date, Tic.Ticket_Price, Tic.Ticket_Status
FROM
	Passengers Pass
JOIN Tickets Tic ON Pass.Passengers_ID = Tic.Passenger_id;

------------------------------------------------------------------- View Data Command
SELECT * FROM view_Passenger;
-------------------------------------------------------------------------------------



------------------------------------------------------------- View For Crew Data
CREATE VIEW view_CrewMember AS
SELECT
	Crew.Full_Name, Crew.Date_of_Birth, Crew.Contact_Phone, Crew.Contact_Email,
	Crew.Experience_Years, Crew.Gender, Crew.License_Number, Crew.Nationality,
	Crew.Role, Crew.Salary
FROM 
	Crew_Members Crew
WHERE
	Crew.Gender = 'Male';

------------------------------------------------------------------- View Data Command
SELECT * FROM view_CrewMember;
-------------------------------------------------------------------------------------