-- SHOWING DATA FOR FOR THE FOLLOWING TABLES USING JOIN
--AIRLINE--AIRCRAFT--MAINTENANCE--FUEL


-- Where Maintenance Status = Pending 
-- Where Refuel Status = Pending

SELECT 
	Air.AirLine_Name, Air.AirLine_Code, Air.Founded_Year, Air.Headquarters, Air.Email, Air.Contact_No,
	Craft.Model, Craft.Manufacturer, Craft.Registration_No, Craft.Total_Seats, Craft.First_Class_Seats, Craft.Business_Class_Seats,
	Craft.Economy_Class_Seats, Main.Maintenance_Type, Main.Maintenance_Date, Main.Status AS Maintenance_Status,
	Fuel.Fuel_Used, Fuel.Fuel_Remaining, Fuel.Fuel_Cost, Fuel.Refuel_Status
FROM AirLines Air
INNER JOIN AirCraft Craft ON Air.Airline_ID = Craft.Airline_id
JOIN Maintenances Main ON Craft.Aircraft_ID = Main.Aircraft_id
JOIN Fuel_Consumption Fuel ON Craft.Aircraft_ID = Fuel.Aircraft_id
WHERE Main.Status = 'Pending' AND Fuel.Refuel_Status = 'Pending';


-- Where Maintenance Status = Completed 
-- Where Refuel Status = Done

SELECT 
	Air.AirLine_Name, Air.AirLine_Code, Air.Founded_Year, Air.Headquarters, Air.Email, Air.Contact_No,
	Craft.Model, Craft.Manufacturer, Craft.Registration_No, Craft.Total_Seats, Craft.First_Class_Seats, Craft.Business_Class_Seats,
	Craft.Economy_Class_Seats, Main.Maintenance_Type, Main.Maintenance_Date, Main.Status AS Maintenance_Status,
	Fuel.Fuel_Used, Fuel.Fuel_Remaining, Fuel.Fuel_Cost, Fuel.Refuel_Status
FROM AirLines Air
INNER JOIN AirCraft Craft ON Air.Airline_ID = Craft.Airline_id
JOIN Maintenances Main ON Craft.Aircraft_ID = Main.Aircraft_id
JOIN Fuel_Consumption Fuel ON Craft.Aircraft_ID = Fuel.Aircraft_id
WHERE Main.Status = 'Completed' AND Fuel.Refuel_Status = 'Done';


-- Not Specified

SELECT 
	Air.AirLine_Name, Air.AirLine_Code, Air.Founded_Year, Air.Headquarters, Air.Email, Air.Contact_No,
	Craft.Model, Craft.Manufacturer, Craft.Registration_No, Craft.Total_Seats, Craft.First_Class_Seats, Craft.Business_Class_Seats,
	Craft.Economy_Class_Seats, Main.Maintenance_Type, Main.Maintenance_Date, Main.Status AS Maintenance_Status,
	Fuel.Fuel_Used, Fuel.Fuel_Remaining, Fuel.Fuel_Cost, Fuel.Refuel_Status
FROM AirLines Air
INNER JOIN AirCraft Craft ON Air.Airline_ID = Craft.Airline_id
JOIN Maintenances Main ON Craft.Aircraft_ID = Main.Aircraft_id
JOIN Fuel_Consumption Fuel ON Craft.Aircraft_ID = Fuel.Aircraft_id;



-- SHOWING DATA FOR FOR THE FOLLOWING TABLES USING JOIN
--AIRPORT--SECURITY--RUNWAYS


-- Where Security Status = Pending

SELECT
	Po.Airport_Name, Po.Airport_Code, Po.Airport_City, Po.Country, Po.TimeZone,
	Sec.Check_Type, Sec.Status AS Security_Status,
	Run.Runway_Length, Run.Runway_Width, Run.Surface_Type
FROM Airports Po
JOIN SecurityCheck Sec ON Po.Airport_ID = Sec.Airport_id
JOIN Runways Run ON Po.Airport_ID = Run.Airport_id
WHERE Sec.Status = 'Pending';


-- Where Security Status = Done

SELECT
	Po.Airport_Name, Po.Airport_Code, Po.Airport_City, Po.Country, Po.TimeZone,
	Sec.Check_Type, Sec.Status AS Security_Status,
	Run.Runway_Length, Run.Runway_Width, Run.Surface_Type
FROM Airports Po
JOIN SecurityCheck Sec ON Po.Airport_ID = Sec.Airport_id
JOIN Runways Run ON Po.Airport_ID = Run.Airport_id
WHERE Sec.Status = 'Completed';


-- Not Specified

SELECT
	Po.Airport_Name, Po.Airport_Code, Po.Airport_City, Po.Country, Po.TimeZone,
	Sec.Check_Type, Sec.Status AS Security_Status,
	Run.Runway_Length, Run.Runway_Width, Run.Surface_Type
FROM Airports Po
JOIN SecurityCheck Sec ON Po.Airport_ID = Sec.Airport_id
JOIN Runways Run ON Po.Airport_ID = Run.Airport_id



-- SHOWING DATA FOR FOR THE FOLLOWING TABLES USING JOIN
--FLIGHTS--FLIGHTS_SCHEDULES--FLIGHT_DELAYS--FLIGHT_CANCELLATIONS--INFLIGHT_ENTERTAINMENT


-- Where Refund Status = Refunded

SELECT
	Fly.Arrival_Time, Fly.Departure_Time, Fly.Duration, Fly.Ticket_Price, Fly.Flights_Status, Del.New_Departure_Time, 
	Del.Reason, Can.Reason, Can.Refund_Status, Enter.Entertainment_Type, Enter.Availability_Status, Sche.Gate_No
FROM Flights Fly 
LEFT JOIN Flight_Delays Del ON Fly.Flight_ID = Del.Flight_id
LEFT JOIN Flight_Cancellations Can ON Fly.Flight_ID = Can.Flight_id
LEFT JOIN InFlight_Entertainment Enter ON Fly.Flight_ID = Enter.Flight_id
LEFT JOIN Flights_Schedules Sche ON Fly.Flight_ID = Sche.Flight_id
WHERE Can.Refund_Status = 'Refunded' 


-- Where flight Status = Cancelled

SELECT
	Fly.Arrival_Time, Fly.Departure_Time, Fly.Duration, Fly.Ticket_Price, Fly.Flights_Status, Del.New_Departure_Time, 
	Del.Reason, Can.Reason, Can.Refund_Status, Enter.Entertainment_Type, Enter.Availability_Status, Sche.Gate_No
FROM Flights Fly 
LEFT JOIN Flight_Delays Del ON Fly.Flight_ID = Del.Flight_id
LEFT JOIN Flight_Cancellations Can ON Fly.Flight_ID = Can.Flight_id
LEFT JOIN InFlight_Entertainment Enter ON Fly.Flight_ID = Enter.Flight_id
LEFT JOIN Flights_Schedules Sche ON Fly.Flight_ID = Sche.Flight_id
WHERE Fly.Flights_Status = 'Cancelled' 


-- Where flight Status = Delayed
-- Where In-Flight_Entertainment Status = Available

SELECT
	Fly.Arrival_Time, Fly.Departure_Time, Fly.Duration, Fly.Ticket_Price, Fly.Flights_Status, Del.New_Departure_Time, 
	Del.Reason, Can.Reason, Can.Refund_Status, Enter.Entertainment_Type, Enter.Availability_Status, Sche.Gate_No
FROM Flights Fly 
LEFT JOIN Flight_Delays Del ON Fly.Flight_ID = Del.Flight_id
LEFT JOIN Flight_Cancellations Can ON Fly.Flight_ID = Can.Flight_id
LEFT JOIN InFlight_Entertainment Enter ON Fly.Flight_ID = Enter.Flight_id
LEFT JOIN Flights_Schedules Sche ON Fly.Flight_ID = Sche.Flight_id
WHERE Fly.Flights_Status = 'Delayed' AND Enter.Availability_Status = 'Available' 


-- Where flight Status = Boarding
-- Where In-Flight_Entertainment Status = Available

SELECT
	Fly.Arrival_Time, Fly.Departure_Time, Fly.Duration, Fly.Ticket_Price, Fly.Flights_Status, Del.New_Departure_Time, 
	Del.Reason, Can.Reason, Can.Refund_Status, Enter.Entertainment_Type, Enter.Availability_Status, Sche.Gate_No
FROM Flights Fly 
LEFT JOIN Flight_Delays Del ON Fly.Flight_ID = Del.Flight_id
LEFT JOIN Flight_Cancellations Can ON Fly.Flight_ID = Can.Flight_id
LEFT JOIN InFlight_Entertainment Enter ON Fly.Flight_ID = Enter.Flight_id
LEFT JOIN Flights_Schedules Sche ON Fly.Flight_ID = Sche.Flight_id
WHERE Fly.Flights_Status = 'Boarding' AND Enter.Availability_Status = 'Available' 


-- Where flight Status = On-Time
-- Where In-Flight_Entertainment Status = Available

SELECT
	Fly.Arrival_Time, Fly.Departure_Time, Fly.Duration, Fly.Ticket_Price, Fly.Flights_Status, Del.New_Departure_Time, 
	Del.Reason, Can.Reason, Can.Refund_Status, Enter.Entertainment_Type, Enter.Availability_Status, Sche.Gate_No
FROM Flights Fly 
LEFT JOIN Flight_Delays Del ON Fly.Flight_ID = Del.Flight_id
LEFT JOIN Flight_Cancellations Can ON Fly.Flight_ID = Can.Flight_id
LEFT JOIN InFlight_Entertainment Enter ON Fly.Flight_ID = Enter.Flight_id
LEFT JOIN Flights_Schedules Sche ON Fly.Flight_ID = Sche.Flight_id
WHERE Fly.Flights_Status = 'On-Time' AND Enter.Availability_Status = 'Available' 


-- Not Specified

SELECT
	Fly.Arrival_Time, Fly.Departure_Time, Fly.Duration, Fly.Ticket_Price, Fly.Flights_Status, Del.New_Departure_Time, 
	Del.Reason, Can.Reason, Can.Refund_Status, Enter.Entertainment_Type, Enter.Availability_Status, Sche.Gate_No
FROM Flights Fly 
LEFT JOIN Flight_Delays Del ON Fly.Flight_ID = Del.Flight_id
LEFT JOIN Flight_Cancellations Can ON Fly.Flight_ID = Can.Flight_id
LEFT JOIN InFlight_Entertainment Enter ON Fly.Flight_ID = Enter.Flight_id
LEFT JOIN Flights_Schedules Sche ON Fly.Flight_ID = Sche.Flight_id




-- SHOWING DATA FOR FOR THE FOLLOWING TABLES USING JOIN
--Crew_Members--Flight_Crew--Flight_Attendance_Record--Crew_Shift


-- Where Attendence Status = Present
-- Where Duty Status = Completed

SELECT
	Crew.Full_Name, Crew.Gender, Crew.Nationality, Crew.Contact_Email, Crew.Contact_Phone, Crew.License_Number, Crew.Role, Crew.Salary,
	Attend.Status AS Attendence_Status, C_Shift.Shift_Start_Time, C_Shift.Shift_End_Time, C_Shift.Duty_Duration, C_Shift.Duty_Status,
	Fly_C.Flight_id
FROM Crew_Members Crew
JOIN Flight_Crew Fly_C ON Crew.Crew_Member_ID = Fly_C.Crew_Member_id
JOIN Flight_Attendance_Record Attend ON Crew.Crew_Member_ID = Attend.Crew_Member_id
JOIN Crew_Shift C_Shift ON Crew.Crew_Member_id = C_Shift.Crew_Member_id
WHERE Attend.Status = 'Present' AND C_Shift.Duty_Status = 'Completed'


-- Where Attendence Status = Present
-- Where Duty Status = Ongoing

SELECT
	Crew.Full_Name, Crew.Gender, Crew.Nationality, Crew.Contact_Email, Crew.Contact_Phone, Crew.License_Number, Crew.Role, Crew.Salary,
	Attend.Status AS Attendence_Status, C_Shift.Shift_Start_Time, C_Shift.Shift_End_Time, C_Shift.Duty_Duration, C_Shift.Duty_Status,
	Fly_C.Flight_id
FROM Crew_Members Crew
JOIN Flight_Crew Fly_C ON Crew.Crew_Member_ID = Fly_C.Crew_Member_id
JOIN Flight_Attendance_Record Attend ON Crew.Crew_Member_ID = Attend.Crew_Member_id
JOIN Crew_Shift C_Shift ON Crew.Crew_Member_id = C_Shift.Crew_Member_id
WHERE Attend.Status = 'Present' AND C_Shift.Duty_Status = 'Ongoing'


-- Where Attendence Status = Present

SELECT
	Crew.Full_Name, Crew.Gender, Crew.Nationality, Crew.Contact_Email, Crew.Contact_Phone, Crew.License_Number, Crew.Role, Crew.Salary,
	Attend.Status AS Attendence_Status, C_Shift.Shift_Start_Time, C_Shift.Shift_End_Time, C_Shift.Duty_Duration, C_Shift.Duty_Status,
	Fly_C.Flight_id
FROM Crew_Members Crew
JOIN Flight_Crew Fly_C ON Crew.Crew_Member_ID = Fly_C.Crew_Member_id
JOIN Flight_Attendance_Record Attend ON Crew.Crew_Member_ID = Attend.Crew_Member_id
JOIN Crew_Shift C_Shift ON Crew.Crew_Member_id = C_Shift.Crew_Member_id
WHERE Attend.Status = 'Absent'


-- Not Specified

SELECT
	Crew.Full_Name, Crew.Gender, Crew.Nationality, Crew.Contact_Email, Crew.Contact_Phone, Crew.License_Number, Crew.Role, Crew.Salary,
	Attend.Status AS Attendence_Status, C_Shift.Shift_Start_Time, C_Shift.Shift_End_Time, C_Shift.Duty_Duration, C_Shift.Duty_Status,
	Fly_C.Flight_id
FROM Crew_Members Crew
JOIN Flight_Crew Fly_C ON Crew.Crew_Member_ID = Fly_C.Crew_Member_id
JOIN Flight_Attendance_Record Attend ON Crew.Crew_Member_ID = Attend.Crew_Member_id
JOIN Crew_Shift C_Shift ON Crew.Crew_Member_id = C_Shift.Crew_Member_id




-- SHOWING DATA FOR FOR THE FOLLOWING TABLES USING JOIN
--Passengers--Passenger_Feedback--Tickets--Seats--Boarding_Passes--Baggages--VIP_Services


-- Not Specified

SELECT
	Pass.Full_Name,Pass.Date_of_Birth, Pass.Gender, Pass.Contact_Email, Pass.Contact_Phone, Pass.Nationality, Pass.Passport_No,
	B.Baggage_Type, B.Weight AS Baggage_Weight,BP.Status AS Boarding_Pass_Status, T.Booking_Date, T.Ticket_Price, T.Ticket_Status, 
	S.Class_Type, S.Seat_No, S.Seat_Status, B.Status AS Baggage_Status,VIP.Service_Type, VIP.Status AS Confirmation_Status,
	Feed.Rating, Feed.Comments 
FROM Passengers Pass
JOIN Passenger_Feedback Feed ON Pass.Passengers_ID = Feed.Passenger_id
JOIN Tickets T ON Pass.Passengers_ID = T.Passenger_id
JOIN Seats S ON T.Seat_id = S.Seat_id
JOIN Baggage B ON Pass.Passengers_ID = B.Passenger_id
JOIN Boarding_Passes BP ON Pass.Passengers_ID = BP.Passenger_id
JOIN VIP_Services VIP ON Pass.Passengers_ID = VIP.Passenger_id




-- SHOWING DATA FOR FOR THE FOLLOWING TABLES USING JOIN
--CARGO--FLIGHTS

-- Where Flight_Status = On-Time

SELECT
	C.Description, C.Weight, C.Sender_Details, C.Receiver_Details, Fly.Departure_Time, Fly.Arrival_Time, Fly.Flights_Status
FROM Cargo C
JOIN Flights Fly ON C.Flight_id = Fly.Flight_ID
WHERE Fly.Flights_Status = 'On-Time'




-- SHOWING DATA FOR FOR THE FOLLOWING TABLES USING JOIN
--Catering--Airline


-- Not Specified

SELECT
	C.Catering_Provider, C.Provider_No AS Provider_Number, C.Rating, A.AirLine_Name, A.Email, A.Contact_No
FROM Catering_Services C
JOIN AirLines A ON C.Airline_id = A.Airline_ID