
-------------------------------------------- AirLines

---- SCALAR FUNCTION (Returns total number of airlines)
CREATE FUNCTION dbo.fn_TotalAirlines()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM AirLines;
    RETURN @count;
END;


------ RUN QUERY
SELECT dbo.fn_TotalAirlines() AS TotalAirlines;



----- TABLE VALUED FUNCTION (Returns airlines filtered by country "input parameter" )
CREATE FUNCTION dbo.fn_AirlinesByCountry(@AirLine_Code NVARCHAR(100))
RETURNS TABLE
AS
RETURN (
    SELECT Airline_ID, Airline_Name, AirLine_Code
    FROM AirLines
    WHERE AirLine_Code = @AirLine_Code
);


-- RUN QUERY 
SELECT * FROM dbo.fn_AirlinesByCountry('BA');

-----------------------------------------------------------------------------------------------



-------------------------------------------- AirCraft

---- SCALAR FUNCTION (Returns total seats for a given Aircraft by Aircraft_ID)

CREATE FUNCTION dbo.fn_TotalSeatsByAircraft(@AircraftID INT)
RETURNS INT
AS
BEGIN
    DECLARE @totalSeats INT;
    SELECT @totalSeats = Total_Seats FROM AirCraft WHERE Aircraft_ID = @AircraftID;
    RETURN @totalSeats;
END;


-- Run query
SELECT dbo.fn_TotalSeatsByAircraft(1) AS TotalSeats;


----- TABLE VALUED FUNCTION (Returns all aircraft models for a given Airline_ID.)
CREATE FUNCTION dbo.fn_AircraftByAirline(@AirlineID INT)
RETURNS TABLE
AS
RETURN (
    SELECT Aircraft_ID, Model, Total_Seats
    FROM AirCraft
    WHERE Airline_ID = @AirlineID
);


-- Run query
SELECT * FROM dbo.fn_AircraftByAirline(2);

-----------------------------------------------------------------------------------------------





-------------------------------------------- Airports

---- SCALAR FUNCTION (Returns number of airports in a given country)
CREATE FUNCTION dbo.fn_AirportsCountByCountry(@Country NVARCHAR(100))
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Airports WHERE Country = @Country;
    RETURN @count;
END;


-- Run query
SELECT dbo.fn_AirportsCountByCountry('UAE') AS TotalAirports;


----- TABLE VALUED FUNCTION (Returns airports in a given city)
CREATE FUNCTION dbo.fn_AirportsByCity(@Airport_City NVARCHAR(100))
RETURNS TABLE
AS
RETURN (
    SELECT Airport_ID, Airport_Name, Airport_City, Country
    FROM Airports
    WHERE Airport_City = @Airport_City
);


-- Run query
SELECT * FROM dbo.fn_AirportsByCity('Dubai');

-----------------------------------------------------------------------------------------------





-------------------------------------------- Flights

---- SCALAR FUNCTION (Returns count of flights for a given Airline)
CREATE FUNCTION dbo.fn_FlightCountByAirline(@AirlineID INT)
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Flights WHERE Airline_ID = @AirlineID;
    RETURN @count;
END;


-- Run query
SELECT dbo.fn_FlightCountByAirline(1) AS FlightCount;



-----------------------------------------------------------------------------------------------






-------------------------------------------- Crew_Members

---- SCALAR FUNCTION (Returns count of crew members by role)
CREATE FUNCTION dbo.fn_CrewCountByRole(@Role NVARCHAR(50))
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Crew_Members WHERE Role = @Role;
    RETURN @count;
END;


-- Run query
SELECT dbo.fn_CrewCountByRole('Captain') AS PilotCount;


----- TABLE VALUED FUNCTION (Returns all crew members for a given airline)
CREATE FUNCTION dbo.fn_CrewByAirline(@AirlineID INT)
RETURNS TABLE
AS
RETURN (
    SELECT Crew_Member_ID, First_Name, Role
    FROM Crew_Members
    WHERE Airline_ID = @AirlineID
);

-- Run query
SELECT * FROM dbo.fn_CrewByAirline(1);

-----------------------------------------------------------------------------------------------





-------------------------------------------- Passengers

---- SCALAR FUNCTION (Returns total passengers count)
CREATE FUNCTION dbo.fn_TotalPassengers()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Passengers;
    RETURN @count;
END;


-- Run query
SELECT dbo.fn_TotalPassengers() AS TotalPassengers;


----- TABLE VALUED FUNCTION (Returns passengers filtered by nationality)
CREATE FUNCTION dbo.fn_PassengersByNationality(@Nationality NVARCHAR(100))
RETURNS TABLE
AS
RETURN (
    SELECT Passengers_ID, First_Name, Last_Name, Nationality
    FROM Passengers
    WHERE Nationality = @Nationality
);

-- Run query
SELECT * FROM dbo.fn_PassengersByNationality('American');

-----------------------------------------------------------------------------------------------






-------------------------------------------- Tickets

---- SCALAR FUNCTION (Returns total tickets sold for a specific flight)
CREATE FUNCTION dbo.fn_TicketsSoldByFlight(@FlightID INT)
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Tickets WHERE Flight_ID = @FlightID;
    RETURN @count;
END;


-- Run query
SELECT dbo.fn_TicketsSoldByFlight(1) AS TicketsSold;


----- TABLE VALUED FUNCTION (Returns all tickets purchased by a given passenger.)
CREATE FUNCTION dbo.fn_TicketsByPassenger(@Passenger_id INT)
RETURNS TABLE
AS
RETURN (
    SELECT Ticket_ID, Flight_ID, Ticket_Price
    FROM Tickets
    WHERE Passenger_id = @Passenger_id
);

-- Run query
SELECT * FROM dbo.fn_TicketsByPassenger(1);
-----------------------------------------------------------------------------------------------
