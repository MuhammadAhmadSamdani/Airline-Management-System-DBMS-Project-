﻿
------------------------------------------ USE DATABASE
USE AirlineManagementSystem


----------------------------------------- ADD DATA IN (AirLines, AirCraft, Airports, Runways, Maintainces, Security, Fuel)
CREATE PROCEDURE AddDataForAirLines
    
	-- AirLines
    @AirLine_name NVARCHAR(100),
    @AirLine_code NVARCHAR(100),
    @AirLine_headquarters NVARCHAR(100),
    @Email NVARCHAR(100),
    @Phone NVARCHAR(100),
    @Founded_year INT,

    -- AirCraft
    @Model NVARCHAR(100),
    @Manufacturer NVARCHAR(100),
    @TotalSeats INT,
    @FirstClassSeats INT,
    @BusinessClassSeats INT,
    @EconomyClassSeats INT,
    @Registration_No INT,

    -- Airports
    @Airport_name NVARCHAR(100),
    @Airport_code NVARCHAR(100),
    @City NVARCHAR(100),
    @Country NVARCHAR(100),
    @Timezone NVARCHAR(100),

    -- Runways
    @Runway_length INT,
    @Runway_width INT,
    @Runway_surface NVARCHAR(100),

    -- Maintenance
    @Maintenance_Type NVARCHAR(100),
    @Maintenance_Date DATE,
    @Maintenance_Status NVARCHAR(20),

    -- Security
    @Security_Check NVARCHAR(20),
    @Status_Check NVARCHAR(20),

    -- Fuel
    @Fuel_Used INT,
    @Fuel_Remaining INT,
    @Fuel_Cost NVARCHAR(100),
    @Refuel_Status NVARCHAR(20)

AS
BEGIN
    -- Pre-validation BEFORE starting transaction
    IF EXISTS (SELECT 1 FROM AirLines WHERE AirLine_Code = @AirLine_code)
    BEGIN
        PRINT '!!! Airline already exists.';
        RETURN;
    END

    IF EXISTS (SELECT 1 FROM AirCraft WHERE Registration_No = @Registration_No)
    BEGIN
        PRINT '!!! Aircraft already exists.';
        RETURN;
    END

    IF EXISTS (SELECT 1 FROM Airports WHERE Airport_Code = @Airport_code)
    BEGIN
        PRINT '!!! Airport already exists.';
        RETURN;
    END

    IF @Fuel_Used < 0 OR @Fuel_Remaining < 0
    BEGIN
        PRINT '!!! Invalid Fuel Consumption: values cannot be negative.';
        RETURN;
    END

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Only now, after all validations passed, do the inserts

		-- AirLines
        INSERT INTO AirLines (AirLine_Name, AirLine_Code, Headquarters, Email, Contact_No, Founded_Year)
        VALUES (@AirLine_name, @AirLine_code, @AirLine_headquarters, @Email, @Phone, @Founded_year);
        DECLARE @NewAirLineID INT = SCOPE_IDENTITY();

		-- AirCrafts
        INSERT INTO AirCraft (Airline_id, Model, Manufacturer, Total_Seats, First_Class_Seats, Business_Class_Seats, Economy_Class_Seats, Registration_No)
        VALUES (@NewAirLineID, @Model, @Manufacturer, @TotalSeats, @FirstClassSeats, @BusinessClassSeats, @EconomyClassSeats, @Registration_No);
        DECLARE @NewAircraftID INT = SCOPE_IDENTITY();

		-- Airports
        INSERT INTO Airports (Airport_Name, Airport_Code, Airport_City, Country, TimeZone)
        VALUES (@Airport_name, @Airport_code, @City, @Country, @Timezone);
        DECLARE @NewAirportID INT = SCOPE_IDENTITY();

		-- Runways
        INSERT INTO Runways (Airport_id, Length, Width, Surface_Type)
        VALUES (@NewAirportID, @Runway_length, @Runway_width, @Runway_surface);

		-- Maintainces
        INSERT INTO Maintenances (Aircraft_id, Maintenance_Type, Maintenance, Status)
        VALUES (@NewAircraftID, @Maintenance_Type, @Maintenance_Date, @Maintenance_Status);

		-- SecurityCheck
        INSERT INTO SecurityCheck (Airport_id, Check_Type, Status)
        VALUES (@NewAirportID, @Security_Check, @Status_Check);

		-- Fuel_Consumption
        INSERT INTO Fuel_Consumption (Aircraft_id, Fuel_Used, Fuel_Remaining, Refuel_Status, Fuel_Cost)
        VALUES (@NewAircraftID, @Fuel_Used, @Fuel_Remaining, @Refuel_Status, @Fuel_Cost);

        COMMIT;

        PRINT 'Data successfully inserted into all tables.';

		-- CHECK ID'S
        SELECT 
            @NewAirLineID AS Airline_ID,
            @NewAircraftID AS Aircraft_ID,
            @NewAirportID AS Airport_ID;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK;

        DECLARE @ErrMsg NVARCHAR(4000) = ERROR_MESSAGE();
        PRINT '❌ Error occurred: ' + @ErrMsg;
    END CATCH
END;

---------------------------------------------- EXEC QUERY FOR THIS PROC

EXEC AddDataForAirLines
    @AirLine_name = 'TIN',
    @AirLine_code = 'TIN123',
    @AirLine_headquarters = 'Lahore, Pakistan',
    @Email = 'chiings',
    @Phone = '923301234367',
    @Founded_year = 2040,

    @Model = 'A312 Neo',
    @Manufacturer = 'Airbus',
    @TotalSeats = 180,
    @FirstClassSeats = 12,
    @BusinessClassSeats = 24,
    @EconomyClassSeats = 144,
    @Registration_No = 1202,

    @Airport_name = 'Karachi Internatinal Airport',
    @Airport_code = 'TIN',
    @City = 'Lahore',
    @Country = 'Pakistan',
    @Timezone = 'GMT+5',

    @Runway_length = 3200,
    @Runway_width = 60,
    @Runway_surface = 'Asphalt',

    @Maintenance_Type = 'Engine Check',
    @Maintenance_Date = '2025-05-11',
    @Maintenance_Status = 'Pending',

    @Security_Check = 'Passenger',
    @Status_Check = 'Pending',

    @Fuel_Used = 5000,
    @Fuel_Remaining = 1200,
    @Fuel_Cost = '600,000 PKR',
    @Refuel_Status = 'Pending';

--------------------------------------------------------------------------------





--------------------------------------------------- ADD DATA FOR ( Flights, Flights_Schedules, Flights_Delays, Flights_Cancellations, In Flight Entertainment)
CREATE PROCEDURE AddDataForFlights
    @Airline_ID INT,
    @Aircraft_ID INT,

    -- Flights
    @Departure_Time DATETIME,
    @Arrival_Time DATETIME,
    @Flights_Status NVARCHAR(50),
    @Ticket_Price DECIMAL(10, 2),

    -- Flights_Schedules
    @Schedule_Gate_No INT,

    -- Flights_Delays
    @Delay_Reason NVARCHAR(20),
    @New_Departure_Time DATETIME,

    -- Flights_Cancellations
    @Cancel_Reason NVARCHAR(20),
    @Refund_Status NVARCHAR(20),

    -- In Flight Entertainment
    @Entertainment_Type NVARCHAR(25),
    @Availability_Status NVARCHAR(25)
AS
BEGIN
    -- Validation
    IF @Departure_Time = @Arrival_Time
    BEGIN
        PRINT 'Invalid Time: Departure and Arrival times cannot be the same.';
        RETURN;
    END

    IF @Ticket_Price <= 0
    BEGIN
        PRINT 'Invalid Price: Ticket price must be greater than 0.';
        RETURN;
    END

    IF @New_Departure_Time = @Departure_Time
    BEGIN
        PRINT 'Invalid New Departure Time: Must be different from original departure time.';
        RETURN;
    END

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Insert into Flights (Flight_id is auto-generated)
        INSERT INTO Flights (Airline_id, Aircraft_id, Departure_Time, Arrival_Time,Flights_Status, Ticket_Price)
        VALUES (@Airline_ID, @Aircraft_ID, @Departure_Time, @Arrival_Time, @Flights_Status, @Ticket_Price);

        -- Get the new Flight ID
        DECLARE @NewFlightID INT = SCOPE_IDENTITY();

        -- Insert into Flights_Schedules
        INSERT INTO Flights_Schedules (Flight_id, Gate_No)
        VALUES (@NewFlightID, @Schedule_Gate_No);

        -- Insert into Flight_Delays
        INSERT INTO Flight_Delays (Flight_id, Reason, New_Departure_Time)
        VALUES (@NewFlightID, @Delay_Reason, @New_Departure_Time);

        -- Insert into Flight_Cancellations
        INSERT INTO Flight_Cancellations (Flight_id, Reason, Refund_Status)
        VALUES (@NewFlightID, @Cancel_Reason, @Refund_Status);

        -- Insert into InFlight_Entertainment
        INSERT INTO InFlight_Entertainment (Flight_id, Entertainment_Type, Availability_Status)
        VALUES (@NewFlightID, @Entertainment_Type, @Availability_Status);

        COMMIT;
        PRINT 'Success: Data inserted successfully.';
        SELECT @NewFlightID AS FlightID;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK;

        DECLARE @ErrMsg NVARCHAR(4000) = ERROR_MESSAGE();
        PRINT 'Error occurred: ' + @ErrMsg;
    END CATCH
END;


------------------------------------------- EXEC QUERY 
EXEC AddDataForFlights
    @Airline_ID = 2,
    @Aircraft_ID = 2,
    @Departure_Time = '2025-05-15 08:00:00',
    @Arrival_Time = '2025-05-15 11:30:00',
    @Flights_Status = 'On-Time',
    @Ticket_Price = 100000.00,

    @Schedule_Gate_No = 3,

    @Delay_Reason = 'Technical',
    @New_Departure_Time = '2025-05-15 09:00:00',

    @Cancel_Reason = 'Weather',
    @Refund_Status = 'Pending',

    @Entertainment_Type = 'Wifi',
    @Availability_Status = 'Available';

----------------------------------------------------------------------------
	



------------------------------------------------- ADD DATA FOR (Crew Members, Flight, Flight Attendance, Crew Shift )
CREATE PROCEDURE AddDataForCrew
    -- Crew Members
    @Airline_id INT,
    @First_Name NVARCHAR(100),
    @Last_Name NVARCHAR(100),
    @Date_of_Birth DATE,
    @Gender NVARCHAR(20),
    @Nationality NVARCHAR(100),
    @Experience INT,
    @Role NVARCHAR(100),
    @Salary DECIMAL(10, 2),
    @Phone NVARCHAR(100),
    @Email NVARCHAR(100),
    @License_Number NVARCHAR(100),

    -- Flight
    @Flight_id INT,

    -- Flight Attendance
    @Status NVARCHAR(20),

    -- Crew Shift
    @Shift_Start_Time DATETIME,
    @Shift_End_Time DATETIME,
    @Duty_Status NVARCHAR(25)
AS
BEGIN
    -- Validate First (No identity consumed yet)
    IF EXISTS (SELECT 1 FROM Crew_Members WHERE First_Name = @First_Name AND Last_Name = @Last_Name)
    BEGIN
        PRINT 'Crew member already exists.';
        RETURN;
    END

    IF EXISTS (SELECT 1 FROM Crew_Members WHERE License_Number = @License_Number)
    BEGIN
        PRINT 'License Number already exists.';
        RETURN;
    END

    IF @Experience < 0
    BEGIN
        PRINT 'Invalid Experience: Must be >= 0.';
        RETURN;
    END

    IF @Salary <= 0
    BEGIN
        PRINT 'Invalid Salary: Must be > 0.';
        RETURN;
    END

    IF @Shift_Start_Time >= @Shift_End_Time
    BEGIN
        PRINT 'Invalid Shift: Start time must be earlier than end time.';
        RETURN;
    END

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Insert Crew Member
        INSERT INTO Crew_Members (Airline_id, First_Name, Last_Name, Date_of_Birth, Gender, Nationality, Experience_Years, Role, Salary, Contact_No, Email, License_Number) 
		VALUES ( @Airline_id, @First_Name, @Last_Name, @Date_of_Birth, @Gender, @Nationality, @Experience, @Role, @Salary, @Phone, @Email, @License_Number);

        DECLARE @NewCrewID INT = SCOPE_IDENTITY();

        -- Insert Flight Crew
        INSERT INTO Flight_Crew (Flight_id, Crew_Member_id)
        VALUES (@Flight_id, @NewCrewID);
        DECLARE @NewFlightCrewID INT = SCOPE_IDENTITY();

        -- Insert Flight Attendance
        INSERT INTO Flight_Attendance_Record (Crew_Member_id, Flight_id, Status)
        VALUES (@NewCrewID, @Flight_id, @Status);
        DECLARE @NewAttendanceID INT = SCOPE_IDENTITY();

        -- Insert Crew Shift
        INSERT INTO Crew_Shift (Crew_Member_id, Shift_Start_Time, Shift_End_Time, Duty_Status)
        VALUES (@NewCrewID, @Shift_Start_Time, @Shift_End_Time, @Duty_Status);
        DECLARE @NewShiftID INT = SCOPE_IDENTITY();

        COMMIT;

        PRINT 'Success: Crew data inserted successfully.';

        SELECT
            @NewCrewID AS CrewID,
            @NewFlightCrewID AS FlightCrewID,
            @NewAttendanceID AS AttendanceID,
            @NewShiftID AS ShiftID;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        PRINT 'Runtime error: ' + @ErrorMessage;
    END CATCH
END;

------------------------------------------------ EXEC QUERY
EXEC AddDataForCrew
    @Airline_id = 2,
    @First_Name = 'Tingu',
    @Last_Name = 'Khan',
    @Date_of_Birth = '1990-02-15',
    @Gender = 'Male',
    @Nationality = 'Pakistani',
    @Experience = 8,
    @Role = 'Pilot',
    @Salary = 750000,
    @Phone = '92301234537',
    @Email = 'ahmed.kan',
    @License_Number = 'PTh123456',
    @Flight_id = 2,
    @Status = 'Present',
    @Shift_Start_Time = '2025-05-11 09:00',
    @Shift_End_Time = '2025-05-11 15:00',
    @Duty_Status = 'Completed';

--------------------------------------------------------------------------------	

	

	
CREATE PROCEDURE AddDataForPassengers
    -- Passengers
    @First_Name NVARCHAR(100),
    @Last_Name NVARCHAR(100),
    @Date_of_Birth DATE,
    @Gender NVARCHAR(20),
    @Nationality NVARCHAR(100),
    @Passport_No NVARCHAR(100),
    @Email NVARCHAR(100),
    @Contact_No NVARCHAR(100),

    -- Tickets
    @Ticket_Status NVARCHAR(20),
    @Ticket_Price DECIMAL(10, 2),
    @Booking DATE,

    -- Baggages
    @Weight INT,
    @Baggage_Type NVARCHAR(20),
    @Baggage_Status NVARCHAR(20),

    -- Passenger Feedback
    @Rating INT,
    @Comments NVARCHAR(100),

    -- Boarding Pass
    @Boarding_Time DATETIME,
    @Boarding_Status NVARCHAR(20),

    -- VIP Service
    @Service_Type NVARCHAR(100),
    @VIP_Status NVARCHAR(20),

    -- Seats
    @Seat_No NVARCHAR(20),
    @Class_Type NVARCHAR(20),
    @Seat_Status NVARCHAR(10),

    -- Flight details
    @Flight_ID INT,
    @Aircraft_ID INT
AS
BEGIN
    BEGIN TRY
        -- Check if Passenger already exists by First_Name and Last_Name or Passport_No
        IF EXISTS (SELECT 1 FROM Passengers WHERE First_Name = @First_Name AND Last_Name = @Last_Name)
        BEGIN
            PRINT '!!! Passenger already exists by name.'
            RETURN
        END

        IF EXISTS (SELECT 1 FROM Passengers WHERE Passport_No = @Passport_No)
        BEGIN
            PRINT '!!! Passenger with this passport number already exists.'
            RETURN
        END

        -- Validate Date of Birth: It cannot be in the future
        IF @Date_of_Birth > GETDATE()
        BEGIN
            PRINT '!!! Invalid Date of Birth: Date of Birth cannot be in the future.'
            RETURN
        END

        -- Validate Weight: Weight cannot be less than 0
        IF @Weight < 0
        BEGIN
            PRINT '!!! Invalid Weight: Weight cannot be less than 0.'
            RETURN
        END

        -- Validate Ticket Price: Ticket price must be greater than 0
        IF @Ticket_Price <= 0
        BEGIN
            PRINT '!!! Invalid Ticket Price: Ticket price must be greater than 0.'
            RETURN
        END

        -- Check if the Seat is already booked
        IF EXISTS (SELECT 1 FROM Seats WHERE Seat_No = @Seat_No AND Seat_Status = 'Reserved')
        BEGIN
            PRINT '!!! Invalid Seat: Seat is already reserved.'
            RETURN
        END

        -- Insert into Passengers Table
        INSERT INTO Passengers (First_Name, Last_Name, Date_of_Birth, Nationality, Passport_No, Email, Contact_No, Gender)
        VALUES (@First_Name, @Last_Name, @Date_of_Birth, @Nationality, @Passport_No, @Email, @Contact_No, @Gender)
        DECLARE @NewPassengerID INT = SCOPE_IDENTITY();

        -- Insert into Seats Table
        INSERT INTO Seats (Aircraft_id, Seat_No, Class_Type, Seat_Status)
        VALUES (@Aircraft_ID, @Seat_No, @Class_Type, 'Reserved')
        DECLARE @NewSeatID INT = SCOPE_IDENTITY();

        -- Insert into Tickets Table
        INSERT INTO Tickets (Passenger_id, Flight_id, Seat_id, Ticket_Status, Ticket_Price, Booking)
        VALUES (@NewPassengerID, @Flight_ID, @NewSeatID, @Ticket_Status, @Ticket_Price, @Booking)
        DECLARE @NewTicketID INT = SCOPE_IDENTITY();

        -- Insert into Baggages Table
        INSERT INTO Baggage (Passenger_id, Weight, Baggage_Type, Status)
        VALUES (@NewPassengerID, @Weight, @Baggage_Type, @Baggage_Status);

        -- Insert into Passenger_Feedback Table
        INSERT INTO Passenger_Feedback (Passenger_id, Flight_id, Rating, Comments)
        VALUES (@NewPassengerID, @Flight_ID, @Rating, @Comments);

        -- Insert into VIP_Services Table
        INSERT INTO VIP_Services (Passenger_id, Flight_id, Service_Type, Status)
        VALUES (@NewPassengerID, @Flight_ID, @Service_Type, @VIP_Status);

        -- Insert into Boarding_Passes Table
        INSERT INTO Boarding_Passes (Ticket_id, Passenger_id, Flight_id, Boarding_Time, Status)
        VALUES (@NewTicketID, @NewPassengerID, @Flight_ID, @Boarding_Time, @Boarding_Status);

        -- Commit the transaction
        COMMIT;
        PRINT 'Success: Data inserted into Passengers, Seats, Tickets, Baggages, Passenger_Feedback, VIP_Services, and Boarding_Passes tables.';

        -- Return the IDs of the newly inserted records
        SELECT 
            @NewPassengerID AS PassengerID,
            @NewTicketID AS TicketID,
            @NewSeatID AS SeatID;
    END TRY
    BEGIN CATCH
        -- Rollback in case of error
        IF @@TRANCOUNT > 0
            ROLLBACK;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        PRINT '!!! Runtime error: ' + @ErrorMessage;
    END CATCH;
END;




EXEC AddDataForPassengers
    @First_Name = 'Uroobah',
    @Last_Name = 'Ovis',
    @Date_of_Birth = '1989-04-15',
    @Gender = 'Female',
    @Nationality = 'American',
    @Passport_No = 'A136356789',
    @Email = 'uroobahovais1@example.com',
    @Contact_No = '1234342390',
    
    @Ticket_Status = 'Sold',
    @Ticket_Price = 251.00,
    @Booking = '2025-05-15',

    @Weight = 20,
    @Baggage_Type = 'Checked',
    @Baggage_Status = 'Loaded',

    @Rating = 5,
    @Comments = 'Great experience!',

    @Boarding_Time = '2025-05-16 10:00:00',
    @Boarding_Status = 'Check In',

    @Service_Type = 'Lounge Access',
    @VIP_Status = 'Confirmed',

    @Seat_No = '14A',
    @Class_Type = 'Business Class',
    @Seat_Status = 'Reserved',

    @Flight_ID = 1,
    @Aircraft_ID = 1;





CREATE PROCEDURE AddDataForCargo

    -- Cargo
    @Flight_ID INT,  -- Added Flight_ID as parameter
    @Description NVARCHAR(100),
    @Weight INT,
    @Sender_Details NVARCHAR(100),
    @Receiver_Details NVARCHAR(100)

AS
BEGIN
    -- Validation: Check if weight is valid
    IF @Weight <= 0
    BEGIN
        PRINT '!!! Weight: Cannot be less than or equal to 0';
        RETURN; -- Exit if validation fails
    END

    BEGIN TRY
        -- Start a transaction
        BEGIN TRANSACTION;

        -- Insert into Cargo table
        INSERT INTO Cargo (Flight_id, Description, Weight, Sender_Details, Receiver_Details)
        VALUES (@Flight_ID, @Description, @Weight, @Sender_Details, @Receiver_Details);
        
        DECLARE @NewCargoID INT = SCOPE_IDENTITY();  -- Get the last inserted Cargo_ID

        -- Commit the transaction if no errors
        COMMIT;
        
        PRINT 'Success: Data inserted into Cargo table.';

        -- Return the new Cargo ID
        SELECT @NewCargoID AS CargoID;

    END TRY
    BEGIN CATCH
        -- Rollback the transaction if an error occurs
        IF @@TRANCOUNT > 0
            ROLLBACK;

        -- Print the error message
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        PRINT '!!! Runtime error: ' + @ErrorMessage;
    END CATCH;
END;


EXEC AddDataForCargo
     @Flight_ID = 1,  -- Example flight ID
    @Description = 'Electronics',  -- Example description
    @Weight = 10,  -- Example weight
    @Sender_Details = 'John Doe, XYZ Corp',  -- Example sender
    @Receiver_Details = 'Jane Smith, ABC Corp';  -- Example receiver

	









CREATE PROCEDURE AddDataForLogistics

    -- Hotel_Partnership
    @Hotel_Name NVARCHAR(100),
    @Location NVARCHAR(100),
    @Hotel_E NVARCHAR(100),
    @Hotel_P NVARCHAR(100),
    @Partnership_Status NVARCHAR(20),
    @Discount_Per NVARCHAR(50),

    -- Catering_Service
    @Catering_Provider NVARCHAR(100),
    @Provider_P NVARCHAR(100),
    @Rating INT,
    @Airline_id INT  -- Added Airline_id as a parameter for Catering_Service table

AS
BEGIN
    -- Check if the Hotel already exists
    IF EXISTS (SELECT 1 FROM Hotel_Partnership WHERE Hotel_Name = @Hotel_Name)
    BEGIN
        PRINT '!!! Hotel already exists.';
        RETURN;
    END

    -- Check if the Catering provider already exists
    IF EXISTS (SELECT 1 FROM Catering_Services WHERE Catering_Provider = @Catering_Provider)
    BEGIN
        PRINT '!!! Catering provider already exists.';
        RETURN;
    END

    BEGIN TRY
        -- Start a transaction
        BEGIN TRANSACTION;

        -- Insert into Hotel_Partnership table
        INSERT INTO Hotel_Partnership (Hotel_Name, Location, Hotel_E, Hotel_P, Partnership_Status, Discount_Per)
        VALUES (@Hotel_Name, @Location, @Hotel_E, @Hotel_P, @Partnership_Status, @Discount_Per);
        
        DECLARE @NewHotelID INT = SCOPE_IDENTITY();  -- Get the last inserted Hotel_ID

        -- Insert into Catering_Services table
        INSERT INTO Catering_Services (Airline_id, Catering_Provider, Provider_P, Rating)
        VALUES (@Airline_id, @Catering_Provider, @Provider_P, @Rating);
        
        DECLARE @NewCateringID INT = SCOPE_IDENTITY();  -- Get the last inserted Catering_ID

        -- Commit the transaction if no errors
        COMMIT;
        
        PRINT 'Success: Data inserted into Hotel_Partnership and Catering_Services tables.';

        -- Return the new IDs
        SELECT 
            @NewHotelID AS HotelID,
            @NewCateringID AS CateringID;

    END TRY
    BEGIN CATCH
        -- Rollback the transaction if an error occurs
        IF @@TRANCOUNT > 0
            ROLLBACK;

        -- Print the error message
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        PRINT '!!! Runtime error: ' + @ErrorMessage;
    END CATCH;
END;



EXEC AddDataForLogistics
    @Hotel_Name = 'Grand',
    @Location = 'New York',
    @Hotel_E = 'grand',
    @Hotel_P = '1234367890',
    @Partnership_Status = 'Active',
    @Discount_Per = '0%',

    @Catering_Provider = 'Deli Catering',
    @Provider_P = '0987654321',
    @Rating = 5,
    @Airline_id = 1; 
