
--------------------------------------------- CREATE TABLE FOR TRIGGER ON AirLine Table
CREATE TABLE Airline_Audit (
    Audit_ID INT IDENTITY(1,1) PRIMARY KEY,
    Airline_ID INT,
    Airline_Name NVARCHAR(100),
    Action VARCHAR(10),
    Action_Date DATETIME DEFAULT GETDATE()
);

----------------------------------------- TRIGGER FOR INSERT DATA
CREATE TRIGGER trg_AirLines_AfterInsert
ON AirLines
AFTER INSERT
AS
BEGIN
    INSERT INTO Airline_Audit (Airline_ID, Airline_Name, Action)
    SELECT Airline_ID, AirLine_Name, 'INSERT'
    FROM INSERTED;
END;
----------------------------------------------------------------------------------------
-- Insert a new airline
INSERT INTO AirLines (AirLine_Name, AirLine_Code, Headquarters, Email, Contact_No, Founded_Year)
VALUES ('TestAir', 'TA001', 'Lahore', 'testair', '923001112233', 2005);

-- Check audit table
SELECT * FROM Airline_Audit;



--------------------------------------------- CREATE TABLE FOR TRIGGER ON Flights Table
CREATE TABLE Flight_Status_Audit (
    Audit_ID INT IDENTITY(1,1) PRIMARY KEY,
    Flight_ID INT,
    Old_Status VARCHAR(50),
    New_Status VARCHAR(50),
    Changed_At DATETIME DEFAULT GETDATE()
);

----------------------------------------- TRIGGER FOR UPDATE DATA
CREATE TRIGGER trg_Flights_AfterUpdate
ON Flights
AFTER UPDATE
AS
BEGIN
    INSERT INTO Flight_Status_Audit (Flight_ID, Old_Status, New_Status)
    SELECT 
        I.Flight_ID,
        D.Flights_Status,
        I.Flights_Status
    FROM INSERTED I
    JOIN DELETED D ON I.Flight_ID = D.Flight_ID
    WHERE I.Flights_Status <> D.Flights_Status;
END;
----------------------------------------------------------------------------------------
-- Check original status
SELECT Flight_ID, Flights_Status FROM Flights WHERE Flight_ID = 1;

-- Update the status
UPDATE Flights
SET Flights_Status = 'Delayed'
WHERE Flight_ID = 1;

-- Check audit table
SELECT * FROM Flight_Status_Audit WHERE Flight_ID = 1;





----------------------------------------------- TRIGGER FOR INSERT DATA
CREATE TRIGGER trg_Passengers_ValidateInsert
ON Passengers
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1 FROM INSERTED WHERE Gender NOT IN ('Male', 'Female', 'Other')
    )
    BEGIN
        RAISERROR('Invalid Gender. Must be Male, Female, or Other.', 16, 1);
        RETURN;
    END

    INSERT INTO Passengers (
        First_Name, Last_Name, Date_of_Birth, Gender,
        Passport_No, Nationality, Email, Contact_No
    )
    SELECT 
        First_Name, Last_Name, Date_of_Birth, Gender,
        Passport_No, Nationality, Email, Contact_No
    FROM INSERTED;
END;
----------------------------------------------------------------------------------------
-- Try inserting invalid gender (should fail)
INSERT INTO Passengers (First_Name, Last_Name, Date_of_Birth, Gender, Passport_No, Nationality, Email, Contact_No)
VALUES ('Ali', 'Khan', '1995-01-01', 'Alien', 'PK12345', 'Pakistani', 'ali@example.com', '03111234567');

-- Now insert valid gender (should work)
INSERT INTO Passengers (First_Name, Last_Name, Date_of_Birth, Gender, Passport_No, Nationality, Email, Contact_No)
VALUES ('Ali', 'Khan', '1995-01-01', 'Male', 'PK12345', 'Pakistani', 'ali@example.com', '03111234567');




----------------------------------------------- TRIGGER FOR ROLLBACK
CREATE TRIGGER trg_AirCraft_SeatCheck
ON AirCraft
AFTER INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1 FROM INSERTED
        WHERE Economy_Class_Seats > Total_Seats
    )
    BEGIN
        RAISERROR('Economy Class Seats cannot be more than Total Seats.', 16, 1);
        ROLLBACK;
    END
END;
----------------------------------------------------------------------------------------
-- Try inserting aircraft with invalid seats
INSERT INTO AirCraft (Airline_ID, Model, Total_Seats, Economy_Class_Seats, Business_Class_Seats, First_Class_Seats)
VALUES (1, 'Boeing 777', 200, 300, 50, 10);  

-- Try a valid insert
INSERT INTO AirCraft (Airline_ID, Model, Total_Seats, Economy_Class_Seats, Business_Class_Seats, First_Class_Seats)
VALUES (1, 'Boeing 777', 300, 200, 50, 10); 

-- Check New Inserted Data
SELECT * FROM AirCraft WHERE Model = 'Boeing 777';

